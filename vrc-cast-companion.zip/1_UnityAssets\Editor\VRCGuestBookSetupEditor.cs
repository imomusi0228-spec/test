#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;
using UnityEngine.UI;
using VRC.Udon;
using VRC.SDK3.Components;
using UdonSharp;

[InitializeOnLoad]
public class VRCGuestBookSetupEditor : EditorWindow
{
    private string baseUrl = "https://test-sepia-three-75.vercel.app/api";
    private string bookId = "";
    private string passcode = "1234";
    private GameObject targetObject = null;
    private GameObject placementTarget = null; // 配置先テーブル/机オブジェクトの手動指定用
    private bool followUser = true; // 手元追従モード (ON:携帯スマホ化, OFF:卓上固定)
    private bool createCallButton = true; // スタンド/呼び出しボタンを生成

    static VRCGuestBookSetupEditor()
    {
        // コンパイル完了時（コード変更時）に自動実行して再構築する
        if (!SessionState.GetBool("VRCGuestBookAutoSetupRun", false))
        {
            SessionState.SetBool("VRCGuestBookAutoSetupRun", true);
            EditorApplication.delayCall += AutoSetupOnLoad;
        }
    }

    private static void AutoSetupOnLoad()
    {
        Debug.Log("[VRCGuestBook] 自動セットアップを作動させます...");
        VRCGuestBookSetupEditor window = ScriptableObject.CreateInstance<VRCGuestBookSetupEditor>();
        window.ExecuteSetup();
        ScriptableObject.DestroyImmediate(window);
    }

    [MenuItem("VRC Cast Companion/セットアップウィンドウ")]
    public static void ShowWindow()
    {
        VRCGuestBookSetupEditor window = GetWindow<VRCGuestBookSetupEditor>("VRC GuestBook Setup");
        window.minSize = new Vector2(400, 370);
        window.maxSize = new Vector2(500, 420);
        window.Show();
    }

    private void OnEnable()
    {
        // ウィンドウ起動時にHierarchyで選択されているオブジェクトがあれば自動でセットアップ先に指定
        if (Selection.activeGameObject != null)
        {
            // 名簿システム自身のオブジェクトはテーブルではないため除外
            if (!Selection.activeGameObject.name.Contains("VRCGuestBook"))
            {
                placementTarget = Selection.activeGameObject;
            }
        }
    }

    private void OnGUI()
    {
        GUILayout.Label("VRChat 顧客名簿システム セットアップ", EditorStyles.boldLabel);
        GUILayout.Space(10);

        baseUrl = EditorGUILayout.TextField("API Base URL", baseUrl);
        bookId = EditorGUILayout.TextField("Book ID (手帳ID)", bookId);
        passcode = EditorGUILayout.TextField("Passcode (暗証番号)", passcode);
        targetObject = (GameObject)EditorGUILayout.ObjectField("Target Tablet (手動配置用)", targetObject, typeof(GameObject), true);
        placementTarget = (GameObject)EditorGUILayout.ObjectField("Placement Target (配置先机)", placementTarget, typeof(GameObject), true);

        // 事前選択に関するヘルプメッセージ
        if (placementTarget != null)
        {
            EditorGUILayout.HelpBox($"【配置対象】「{placementTarget.name}」の上にスマホとスタンドを配置しますわ！", MessageType.Info);
        }
        else
        {
            EditorGUILayout.HelpBox("【ヒント】Hierarchyで設置したい机などを選択してからこのウィンドウを開くと、自動的に配置先に指定されますわ！", MessageType.None);
        }

        followUser = EditorGUILayout.Toggle("手元追従モード (携帯スマホ化)", followUser);
        createCallButton = EditorGUILayout.Toggle("充電スタンド/呼び出しボタン生成", createCallButton);

        GUILayout.Space(20);

        if (GUILayout.Button("自動セットアップを実行", GUILayout.Height(35)))
        {
            ExecuteSetup();
            Close();
        }
    }

    private void ExecuteSetup()
    {
        // 既存のパックを検索
        GameObject packGo = GameObject.Find("VRCGuestBook_Pack (1)");
        if (packGo == null) packGo = GameObject.Find("VRCGuestBook_Pack");

        UdonBehaviour udonBehaviour = null;
        VRCGuestBook guestBook = null;

        // UdonProgramAsset のロード
        string assetPath = "Assets/UdonSharp/VRCGuestBook_UdonProgramAsset.asset";
        UdonSharpProgramAsset programAsset = AssetDatabase.LoadAssetAtPath<UdonSharpProgramAsset>(assetPath);
        if (programAsset == null)
        {
            programAsset = ScriptableObject.CreateInstance<UdonSharpProgramAsset>();
            MonoScript csScript = AssetDatabase.LoadAssetAtPath<MonoScript>("Assets/UdonSharp/VRCGuestBook.cs");
            if (csScript != null)
            {
                programAsset.sourceCsScript = csScript;
                AssetDatabase.CreateAsset(programAsset, assetPath);
                AssetDatabase.SaveAssets();
                AssetDatabase.Refresh();
            }
            else
            {
                EditorUtility.DisplayDialog("エラー", "Assets/UdonSharp/VRCGuestBook.cs が見つかりませんでした。", "OK");
                return;
            }
        }

        if (packGo != null)
        {
            Transform systemT = packGo.transform.Find("VRCGuestBook_System");
            if (systemT != null)
            {
                udonBehaviour = systemT.GetComponent<UdonBehaviour>();
                guestBook = (VRCGuestBook)UdonSharpEditor.UdonSharpEditorUtility.GetProxyBehaviour(udonBehaviour);
            }
            
            // 既存の動的UIやボタン、スタンドを一旦削除してクリーンビルド
            Transform canvasT = packGo.transform.Find("VRCGuestBook_Canvas");
            if (canvasT != null) Undo.DestroyObjectImmediate(canvasT.gameObject);
            Transform callBtnT = packGo.transform.Find("VRCGuestBook_CallButton");
            if (callBtnT != null) Undo.DestroyObjectImmediate(callBtnT.gameObject);
            Transform standT = packGo.transform.Find("VRCGuestBook_SmartphoneStand");
            if (standT != null) Undo.DestroyObjectImmediate(standT.gameObject);
            
            Debug.Log("[VRCGuestBook] 既存の名簿パックを上書き更新します。");
        }
        else
        {
            packGo = new GameObject("VRCGuestBook_Pack (1)");
            Undo.RegisterCreatedObjectUndo(packGo, "Create VRCGuestBook_Pack (1)");
            Debug.Log("[VRCGuestBook] 新規名簿パックを作成します。");
        }

        // テーブル（配置先）の選択と位置合わせ
        GameObject table = placementTarget;
        if (table == null)
        {
            if (Selection.activeGameObject != null && !Selection.activeGameObject.name.Contains("VRCGuestBook"))
            {
                table = Selection.activeGameObject;
                placementTarget = table;
            }
        }
        if (table == null)
        {
            table = GameObject.Find("Circle Coffee Table");
            if (table == null) table = GameObject.Find("circular_coffee_table");
        }
        
        Vector3 tablePos = new Vector3(0f, 0.5f, 0f); // デフォルト位置
        Quaternion tableRot = Quaternion.identity;
        if (table != null)
        {
            tablePos = table.transform.position;
            tableRot = table.transform.rotation;
            Renderer tableRend = table.GetComponentInChildren<Renderer>();
            if (tableRend != null)
            {
                tablePos.y = tableRend.bounds.max.y; // 天板の最上部Y座標
            }
            else
            {
                tablePos.y += 0.53f; // 推定されるテーブルの高さ
            }
            Debug.Log("[VRCGuestBook] 配置先オブジェクトを決定しました: " + table.name + " 位置: " + tablePos);
        }

        // 親パックの位置をテーブルの真上に設定
        packGo.transform.position = tablePos;
        packGo.transform.rotation = tableRot;

        // System オブジェクトのセットアップ
        if (udonBehaviour == null)
        {
            GameObject systemGo = new GameObject("VRCGuestBook_System");
            Undo.RegisterCreatedObjectUndo(systemGo, "Create VRCGuestBook_System");
            systemGo.transform.SetParent(packGo.transform, false);
            udonBehaviour = systemGo.AddComponent<UdonBehaviour>();
            udonBehaviour.programSource = programAsset;
            guestBook = (VRCGuestBook)UdonSharpEditor.UdonSharpEditorUtility.GetProxyBehaviour(udonBehaviour);
        }

        // URL Buffer オブジェクトのセットアップ
        VRCUrlInputField urlBuffer = null;
        Transform urlBufferT = packGo.transform.Find("VRCGuestBook_UrlBuffer");
        if (urlBufferT != null)
        {
            urlBuffer = urlBufferT.GetComponent<VRCUrlInputField>();
        }
        if (urlBuffer == null)
        {
            GameObject bufferGo = new GameObject("VRCGuestBook_UrlBuffer");
            Undo.RegisterCreatedObjectUndo(bufferGo, "Create VRCGuestBook_UrlBuffer");
            bufferGo.transform.SetParent(packGo.transform, false);
            urlBuffer = bufferGo.AddComponent<VRCUrlInputField>();
            bufferGo.AddComponent<InputField>();
            bufferGo.SetActive(false);
        }

        // スマホ筐体のセットアップ
        GameObject phoneGo = null;
        Transform existingPhone = packGo.transform.Find("VRCGuestBook_Smartphone");
        if (existingPhone != null)
        {
            Undo.DestroyObjectImmediate(existingPhone.gameObject);
        }

        // 角丸スマートフォンの組み立て
        phoneGo = new GameObject("VRCGuestBook_Smartphone");
        Undo.RegisterCreatedObjectUndo(phoneGo, "Create VRCGuestBook_Smartphone");
        phoneGo.name = "VRCGuestBook_Smartphone";
        phoneGo.transform.SetParent(packGo.transform, false);
        // スタンドに寄りかかる初期ローカル座標
        phoneGo.transform.localPosition = new Vector3(0f, 0.075f, 0.002f);
        phoneGo.transform.localRotation = Quaternion.Euler(20f, 0f, 0f); // 20度傾ける

        // URP対応の安全なマテリアル作成
        Shader safeShader = GetSafeShader();
        Material bodyMat = new Material(safeShader);
        bodyMat.color = new Color(0.12f, 0.12f, 0.15f);
        if (safeShader.name.Contains("Universal Render Pipeline")) {
            bodyMat.SetFloat("_Metallic", 0.9f);
            bodyMat.SetFloat("_Smoothness", 0.7f);
        } else {
            bodyMat.SetFloat("_Metallic", 0.9f);
            bodyMat.SetFloat("_Glossiness", 0.7f);
        }

        Material screenMat = new Material(safeShader);
        screenMat.color = new Color(0.02f, 0.02f, 0.03f);
        if (safeShader.name.Contains("Universal Render Pipeline")) {
            screenMat.SetFloat("_Metallic", 0.1f);
            screenMat.SetFloat("_Smoothness", 0.95f);
        } else {
            screenMat.SetFloat("_Metallic", 0.1f);
            screenMat.SetFloat("_Glossiness", 0.95f);
        }

        Material metalMat = new Material(safeShader);
        metalMat.color = new Color(0.8f, 0.8f, 0.85f);
        if (safeShader.name.Contains("Universal Render Pipeline")) {
            metalMat.SetFloat("_Metallic", 0.95f);
            metalMat.SetFloat("_Smoothness", 0.8f);
        } else {
            metalMat.SetFloat("_Metallic", 0.95f);
            metalMat.SetFloat("_Glossiness", 0.8f);
        }

        float w = 0.08f;
        float h = 0.16f;
        float d = 0.008f;
        float r = 0.008f;

        // ボディプレート中央
        GameObject centerCube = GameObject.CreatePrimitive(PrimitiveType.Cube);
        centerCube.name = "Body_Center";
        centerCube.transform.SetParent(phoneGo.transform, false);
        centerCube.transform.localScale = new Vector3(w - r * 2f, h, d);
        centerCube.GetComponent<Renderer>().material = bodyMat;
        DestroyImmediate(centerCube.GetComponent<Collider>());

        // 左右サイド
        GameObject leftCube = GameObject.CreatePrimitive(PrimitiveType.Cube);
        leftCube.name = "Body_Left";
        leftCube.transform.SetParent(phoneGo.transform, false);
        leftCube.transform.localPosition = new Vector3(-(w / 2f - r / 2f), 0f, 0f);
        leftCube.transform.localScale = new Vector3(r, h - r * 2f, d);
        leftCube.GetComponent<Renderer>().material = bodyMat;
        DestroyImmediate(leftCube.GetComponent<Collider>());

        GameObject rightCube = GameObject.CreatePrimitive(PrimitiveType.Cube);
        rightCube.name = "Body_Right";
        rightCube.transform.SetParent(phoneGo.transform, false);
        rightCube.transform.localPosition = new Vector3((w / 2f - r / 2f), 0f, 0f);
        rightCube.transform.localScale = new Vector3(r, h - r * 2f, d);
        rightCube.GetComponent<Renderer>().material = bodyMat;
        DestroyImmediate(rightCube.GetComponent<Collider>());

        // 四隅
        string[] cornerNames = { "Corner_TL", "Corner_TR", "Corner_BL", "Corner_BR" };
        Vector3[] cornerPositions = {
            new Vector3(-(w / 2f - r), (h / 2f - r), 0f),
            new Vector3((w / 2f - r), (h / 2f - r), 0f),
            new Vector3(-(w / 2f - r), -(h / 2f - r), 0f),
            new Vector3((w / 2f - r), -(h / 2f - r), 0f)
        };
        for (int i = 0; i < 4; i++)
        {
            GameObject corner = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            corner.name = cornerNames[i];
            corner.transform.SetParent(phoneGo.transform, false);
            corner.transform.localPosition = cornerPositions[i];
            corner.transform.localRotation = Quaternion.Euler(90f, 0f, 0f);
            corner.transform.localScale = new Vector3(r * 2f, d / 2f, r * 2f);
            corner.GetComponent<Renderer>().material = bodyMat;
            DestroyImmediate(corner.GetComponent<Collider>());
        }

        // 液晶画面
        GameObject screen = GameObject.CreatePrimitive(PrimitiveType.Cube);
        screen.name = "Display_Screen";
        screen.transform.SetParent(phoneGo.transform, false);
        screen.transform.localPosition = new Vector3(0f, 0f, d / 2f + 0.0002f);
        screen.transform.localScale = new Vector3(w - 0.004f, h - 0.012f, 0.0005f);
        screen.GetComponent<Renderer>().material = screenMat;
        DestroyImmediate(screen.GetComponent<Collider>());

        // スピーカー
        GameObject speaker = GameObject.CreatePrimitive(PrimitiveType.Cube);
        speaker.name = "Speaker_Slit";
        speaker.transform.SetParent(phoneGo.transform, false);
        speaker.transform.localPosition = new Vector3(0f, h / 2f - 0.005f, d / 2f + 0.0003f);
        speaker.transform.localScale = new Vector3(0.015f, 0.0015f, 0.0002f);
        speaker.GetComponent<Renderer>().material = metalMat;
        DestroyImmediate(speaker.GetComponent<Collider>());

        BoxCollider boxCol = phoneGo.AddComponent<BoxCollider>();
        boxCol.size = new Vector3(w, h, d);

        if (!followUser)
        {
            Rigidbody rb = phoneGo.AddComponent<Rigidbody>();
            rb.mass = 0.5f;
            rb.useGravity = true;

            System.Type pickupType = System.Type.GetType("VRC.SDKBase.VRC_Pickup, VRCSDKBase");
            if (pickupType != null) phoneGo.AddComponent(pickupType);
        }
        else
        {
            boxCol.isTrigger = true;
        }

        if (guestBook != null)
        {
            Undo.RecordObject(guestBook, "VRCGuestBook Setup Reference");
            guestBook.urlBufferInputField = urlBuffer;
            guestBook.baseUrl = new VRC.SDKBase.VRCUrl(baseUrl);
            if (string.IsNullOrEmpty(guestBook.bookId)) guestBook.bookId = bookId;
            if (string.IsNullOrEmpty(guestBook.passcode)) guestBook.passcode = passcode;
            guestBook.tabletObject = phoneGo;

            // UI Canvasの自動生成
            CreateUI(udonBehaviour, guestBook, packGo, phoneGo);

            // スタンドの自動生成
            if (createCallButton)
            {
                if (followUser)
                {
                    CreateSmartphoneStand(udonBehaviour, guestBook, packGo, phoneGo);
                }
                else
                {
                    CreateCallButton(udonBehaviour, guestBook, packGo, phoneGo);
                }
            }

            UdonSharpEditor.UdonSharpEditorUtility.CopyProxyToUdon(guestBook);
            EditorUtility.SetDirty(guestBook);
            EditorUtility.SetDirty(udonBehaviour);
            
            UnityEditor.SceneManagement.EditorSceneManager.MarkSceneDirty(UnityEngine.SceneManagement.SceneManager.GetActiveScene());
            
            Debug.Log("[VRCGuestBook] 自動セットアップおよびテーブル配置が正常に完了しました。");
        }
    }

    private static void CreateUI(UdonBehaviour udonBehaviour, VRCGuestBook guestBook, GameObject packGo, GameObject phoneGo)
    {
        GameObject canvasGo = new GameObject("VRCGuestBook_Canvas");
        Undo.RegisterCreatedObjectUndo(canvasGo, "Create VRCGuestBook_Canvas");
        canvasGo.transform.SetParent(packGo.transform, false);
        
        Canvas canvas = canvasGo.AddComponent<Canvas>();
        canvas.renderMode = RenderMode.WorldSpace;
        canvasGo.AddComponent<CanvasScaler>();
        canvasGo.AddComponent<GraphicRaycaster>();
        canvasGo.AddComponent<VRC.SDKBase.VRC_UiShape>();

        // スマホ画面の表面に吸着
        canvasGo.transform.position = phoneGo.transform.position + phoneGo.transform.forward * 0.0042f;
        canvasGo.transform.rotation = phoneGo.transform.rotation;
        canvasGo.transform.localScale = new Vector3(0.00017f, 0.00017f, 1f);

        RectTransform canvasRect = canvasGo.GetComponent<RectTransform>();
        canvasRect.sizeDelta = new Vector2(450f, 800f);
        guestBook.canvasObject = canvasGo;

        // 背景
        GameObject bgGo = new GameObject("Background");
        Undo.RegisterCreatedObjectUndo(bgGo, "Create Background");
        bgGo.transform.SetParent(canvasGo.transform, false);
        Image bgImg = bgGo.AddComponent<Image>();
        bgImg.color = new Color(0.04f, 0.04f, 0.08f, 0.98f);
        RectTransform bgRect = bgGo.GetComponent<RectTransform>();
        bgRect.anchorMin = Vector2.zero;
        bgRect.anchorMax = Vector2.one;
        bgRect.sizeDelta = Vector2.zero;

        Font defaultFont = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
        DefaultControls.Resources uiResources = new DefaultControls.Resources();

        // (A) GuestPanel
        GameObject guestPanel = new GameObject("GuestPanel");
        Undo.RegisterCreatedObjectUndo(guestPanel, "Create GuestPanel");
        guestPanel.transform.SetParent(canvasGo.transform, false);
        RectTransform guestRect = guestPanel.AddComponent<RectTransform>();
        guestRect.anchorMin = Vector2.zero;
        guestRect.anchorMax = Vector2.one;
        guestRect.sizeDelta = Vector2.zero;

        // タイトル
        GameObject titleGo = new GameObject("Title");
        Undo.RegisterCreatedObjectUndo(titleGo, "Create Title");
        titleGo.transform.SetParent(guestPanel.transform, false);
        Text titleText = titleGo.AddComponent<Text>();
        titleText.text = "GUEST BOOK";
        titleText.font = defaultFont;
        titleText.fontSize = 24;
        titleText.fontStyle = FontStyle.Bold;
        titleText.alignment = TextAnchor.MiddleCenter;
        titleText.color = new Color(0f, 0.94f, 1f);
        RectTransform titleRect = titleGo.GetComponent<RectTransform>();
        titleRect.anchorMin = new Vector2(0.05f, 0.86f);
        titleRect.anchorMax = new Vector2(0.95f, 0.94f);
        titleRect.sizeDelta = Vector2.zero;

        // お名前ラベルとInputField
        GameObject nameLabelGo = new GameObject("NameLabel");
        Undo.RegisterCreatedObjectUndo(nameLabelGo, "Create NameLabel");
        nameLabelGo.transform.SetParent(guestPanel.transform, false);
        Text nameLabel = nameLabelGo.AddComponent<Text>();
        nameLabel.text = "お名前 (Your Name)";
        nameLabel.font = defaultFont;
        nameLabel.fontSize = 14;
        nameLabel.color = new Color(0.8f, 0.8f, 0.9f);
        RectTransform nameLabelRect = nameLabelGo.GetComponent<RectTransform>();
        nameLabelRect.anchorMin = new Vector2(0.12f, 0.77f);
        nameLabelRect.anchorMax = new Vector2(0.88f, 0.82f);
        nameLabelRect.sizeDelta = Vector2.zero;

        GameObject nameInputGo = DefaultControls.CreateInputField(uiResources);
        Undo.RegisterCreatedObjectUndo(nameInputGo, "Create NameInputField");
        nameInputGo.name = "NameInputField";
        nameInputGo.transform.SetParent(guestPanel.transform, false);
        InputField nameInput = nameInputGo.GetComponent<InputField>();
        nameInput.textComponent.font = defaultFont;
        nameInput.textComponent.fontSize = 15;
        nameInput.textComponent.color = Color.white;
        nameInput.placeholder.GetComponent<Text>().font = defaultFont;
        nameInput.placeholder.GetComponent<Text>().fontSize = 13;
        nameInput.placeholder.GetComponent<Text>().text = "お名前を入力しておくれ...";
        nameInput.placeholder.GetComponent<Text>().color = new Color(0.5f, 0.5f, 0.6f);
        RectTransform nameInputRect = nameInputGo.GetComponent<RectTransform>();
        nameInputRect.anchorMin = new Vector2(0.12f, 0.69f);
        nameInputRect.anchorMax = new Vector2(0.88f, 0.75f);
        nameInputRect.sizeDelta = Vector2.zero;

        // キャスト選択ラベル
        GameObject castLabelGo = new GameObject("CastSelectLabel");
        Undo.RegisterCreatedObjectUndo(castLabelGo, "Create CastSelectLabel");
        castLabelGo.transform.SetParent(guestPanel.transform, false);
        Text castLabel = castLabelGo.AddComponent<Text>();
        castLabel.text = "出勤キャスト (クリックで自動入力)";
        castLabel.font = defaultFont;
        castLabel.fontSize = 13;
        castLabel.color = new Color(0.7f, 0.7f, 0.8f);
        RectTransform castLabelRect = castLabelGo.GetComponent<RectTransform>();
        castLabelRect.anchorMin = new Vector2(0.12f, 0.61f);
        castLabelRect.anchorMax = new Vector2(0.88f, 0.65f);
        castLabelRect.sizeDelta = Vector2.zero;

        // キャストボタン
        GameObject[] castBtns = new GameObject[5];
        Text[] castTexts = new Text[5];
        for (int i = 0; i < 5; i++)
        {
            GameObject castBtnGo = DefaultControls.CreateButton(uiResources);
            castBtnGo.name = "CastButton_" + i;
            Undo.RegisterCreatedObjectUndo(castBtnGo, "Create CastButton_" + i);
            castBtnGo.transform.SetParent(guestPanel.transform, false);
            
            Button btn = castBtnGo.GetComponent<Button>();
            Text txt = btn.GetComponentInChildren<Text>();
            txt.text = "キャスト " + (i + 1);
            txt.font = defaultFont;
            txt.fontSize = 11;
            txt.color = Color.white;
            btn.image.color = new Color(0.15f, 0.15f, 0.25f);
            
            RectTransform btnRect = castBtnGo.GetComponent<RectTransform>();
            if (i == 0) { btnRect.anchorMin = new Vector2(0.12f, 0.53f); btnRect.anchorMax = new Vector2(0.48f, 0.58f); }
            else if (i == 1) { btnRect.anchorMin = new Vector2(0.52f, 0.53f); btnRect.anchorMax = new Vector2(0.88f, 0.58f); }
            else if (i == 2) { btnRect.anchorMin = new Vector2(0.12f, 0.46f); btnRect.anchorMax = new Vector2(0.48f, 0.51f); }
            else if (i == 3) { btnRect.anchorMin = new Vector2(0.52f, 0.46f); btnRect.anchorMax = new Vector2(0.88f, 0.51f); }
            else { btnRect.anchorMin = new Vector2(0.32f, 0.39f); btnRect.anchorMax = new Vector2(0.68f, 0.44f); }
            btnRect.sizeDelta = Vector2.zero;
            
            castBtns[i] = castBtnGo;
            castTexts[i] = txt;
            
            RegisterUdonEvent(btn, udonBehaviour, "OnCastClick" + i);
            castBtnGo.SetActive(false);
        }
        guestBook.castButtons = castBtns;
        guestBook.castNameTexts = castTexts;

        // コメントラベル
        GameObject commentLabelGo = new GameObject("CommentLabel");
        Undo.RegisterCreatedObjectUndo(commentLabelGo, "Create CommentLabel");
        commentLabelGo.transform.SetParent(guestPanel.transform, false);
        Text commentLabel = commentLabelGo.AddComponent<Text>();
        commentLabel.text = "ひとことコメント (Comment)";
        commentLabel.font = defaultFont;
        commentLabel.fontSize = 14;
        commentLabel.color = new Color(0.8f, 0.8f, 0.9f);
        RectTransform commentLabelRect = commentLabelGo.GetComponent<RectTransform>();
        commentLabelRect.anchorMin = new Vector2(0.12f, 0.32f);
        commentLabelRect.anchorMax = new Vector2(0.88f, 0.37f);
        commentLabelRect.sizeDelta = Vector2.zero;

        GameObject commentInputGo = DefaultControls.CreateInputField(uiResources);
        Undo.RegisterCreatedObjectUndo(commentInputGo, "Create CommentInputField");
        commentInputGo.name = "CommentInputField";
        commentInputGo.transform.SetParent(guestPanel.transform, false);
        InputField commentInput = commentInputGo.GetComponent<InputField>();
        commentInput.textComponent.font = defaultFont;
        commentInput.textComponent.fontSize = 15;
        commentInput.textComponent.color = Color.white;
        commentInput.placeholder.GetComponent<Text>().font = defaultFont;
        commentInput.placeholder.GetComponent<Text>().fontSize = 13;
        commentInput.placeholder.GetComponent<Text>().text = "コメントを入力しておくれ...";
        commentInput.placeholder.GetComponent<Text>().color = new Color(0.5f, 0.5f, 0.6f);
        RectTransform commentInputRect = commentInputGo.GetComponent<RectTransform>();
        commentInputRect.anchorMin = new Vector2(0.12f, 0.22f);
        commentInputRect.anchorMax = new Vector2(0.88f, 0.29f);
        commentInputRect.sizeDelta = Vector2.zero;

        // 記名ボタン
        GameObject registerBtnGo = DefaultControls.CreateButton(uiResources);
        Undo.RegisterCreatedObjectUndo(registerBtnGo, "Create RegisterButton");
        registerBtnGo.name = "RegisterButton";
        registerBtnGo.transform.SetParent(guestPanel.transform, false);
        Button registerBtn = registerBtnGo.GetComponent<Button>();
        registerBtn.GetComponentInChildren<Text>().text = "記名する (Send)";
        registerBtn.GetComponentInChildren<Text>().font = defaultFont;
        registerBtn.GetComponentInChildren<Text>().fontSize = 16;
        registerBtn.GetComponentInChildren<Text>().fontStyle = FontStyle.Bold;
        registerBtn.GetComponentInChildren<Text>().color = Color.white;
        registerBtn.image.color = new Color(0.6f, 0f, 1f);
        RectTransform registerBtnRect = registerBtnGo.GetComponent<RectTransform>();
        registerBtnRect.anchorMin = new Vector2(0.22f, 0.10f);
        registerBtnRect.anchorMax = new Vector2(0.78f, 0.17f);
        registerBtnRect.sizeDelta = Vector2.zero;

        // ロックボタン (🔑)
        GameObject lockBtnGo = DefaultControls.CreateButton(uiResources);
        Undo.RegisterCreatedObjectUndo(lockBtnGo, "Create LockButton");
        lockBtnGo.name = "LockButton";
        lockBtnGo.transform.SetParent(lockPanel.transform, false);
        Button lockBtn = lockBtnGo.GetComponent<Button>();
        lockBtn.GetComponentInChildren<Text>().text = "🔑";
        lockBtn.GetComponentInChildren<Text>().font = defaultFont;
        lockBtn.GetComponentInChildren<Text>().fontSize = 15;
        lockBtn.image.color = new Color(0.15f, 0.15f, 0.25f);
        RectTransform lockBtnRect = lockBtnGo.GetComponent<RectTransform>();
        lockBtnRect.anchorMin = new Vector2(0.84f, 0.89f);
        lockBtnRect.anchorMax = new Vector2(0.94f, 0.95f);
        lockBtnRect.sizeDelta = Vector2.zero;

        // (B) LockPanel
        GameObject lockPanel = new GameObject("LockPanel");
        Undo.RegisterCreatedObjectUndo(lockPanel, "Create LockPanel");
        lockPanel.transform.SetParent(canvasGo.transform, false);
        RectTransform lockPanelRect = lockPanel.AddComponent<RectTransform>();
        lockPanelRect.anchorMin = Vector2.zero;
        lockPanelRect.anchorMax = Vector2.one;
        lockPanelRect.sizeDelta = Vector2.zero;
        lockPanel.SetActive(false);

        GameObject lockTitleGo = new GameObject("LockTitle");
        Undo.RegisterCreatedObjectUndo(lockTitleGo, "Create LockTitle");
        lockTitleGo.transform.SetParent(lockPanel.transform, false);
        Text lockTitleText = lockTitleGo.AddComponent<Text>();
        lockTitleText.text = "CAST AREA LOCK";
        lockTitleText.font = defaultFont;
        lockTitleText.fontSize = 22;
        lockTitleText.fontStyle = FontStyle.Bold;
        lockTitleText.alignment = TextAnchor.MiddleCenter;
        lockTitleText.color = new Color(1f, 0f, 0.4f);
        RectTransform lockTitleRect = lockTitleGo.GetComponent<RectTransform>();
        lockTitleRect.anchorMin = new Vector2(0.05f, 0.78f);
        lockTitleRect.anchorMax = new Vector2(0.95f, 0.88f);
        lockTitleRect.sizeDelta = Vector2.zero;

        GameObject passcodeLabelGo = new GameObject("PasscodeLabel");
        Undo.RegisterCreatedObjectUndo(passcodeLabelGo, "Create PasscodeLabel");
        passcodeLabelGo.transform.SetParent(lockPanel.transform, false);
        Text passcodeLabel = passcodeLabelGo.AddComponent<Text>();
        passcodeLabel.text = "暗証番号を入力してください";
        passcodeLabel.font = defaultFont;
        passcodeLabel.fontSize = 13;
        passcodeLabel.alignment = TextAnchor.MiddleCenter;
        passcodeLabel.color = new Color(0.8f, 0.8f, 0.9f);
        RectTransform passcodeLabelRect = passcodeLabelGo.GetComponent<RectTransform>();
        passcodeLabelRect.anchorMin = new Vector2(0.05f, 0.63f);
        passcodeLabelRect.anchorMax = new Vector2(0.95f, 0.69f);
        passcodeLabelRect.sizeDelta = Vector2.zero;

        GameObject passcodeInputGo = DefaultControls.CreateInputField(uiResources);
        Undo.RegisterCreatedObjectUndo(passcodeInputGo, "Create PasscodeInputField");
        passcodeInputGo.name = "PasscodeInputField";
        passcodeInputGo.transform.SetParent(lockPanel.transform, false);
        InputField passcodeInput = passcodeInputGo.GetComponent<InputField>();
        passcodeInput.textComponent.font = defaultFont;
        passcodeInput.textComponent.fontSize = 18;
        passcodeInput.textComponent.color = Color.white;
        passcodeInput.textComponent.alignment = TextAnchor.MiddleCenter;
        passcodeInput.inputType = InputField.InputType.Password;
        passcodeInput.placeholder.GetComponent<Text>().font = defaultFont;
        passcodeInput.placeholder.GetComponent<Text>().fontSize = 13;
        passcodeInput.placeholder.GetComponent<Text>().text = "Passcode...";
        passcodeInput.placeholder.GetComponent<Text>().color = new Color(0.5f, 0.5f, 0.6f);
        passcodeInput.placeholder.GetComponent<Text>().alignment = TextAnchor.MiddleCenter;
        RectTransform passcodeInputRect = passcodeInputGo.GetComponent<RectTransform>();
        passcodeInputRect.anchorMin = new Vector2(0.25f, 0.49f);
        passcodeInputRect.anchorMax = new Vector2(0.75f, 0.57f);
        passcodeInputRect.sizeDelta = Vector2.zero;

        GameObject unlockBtnGo = DefaultControls.CreateButton(uiResources);
        Undo.RegisterCreatedObjectUndo(unlockBtnGo, "Create UnlockButton");
        unlockBtnGo.name = "UnlockButton";
        unlockBtnGo.transform.SetParent(lockPanel.transform, false);
        Button unlockBtn = unlockBtnGo.GetComponent<Button>();
        unlockBtn.GetComponentInChildren<Text>().text = "解除 (Unlock)";
        unlockBtn.GetComponentInChildren<Text>().font = defaultFont;
        unlockBtn.GetComponentInChildren<Text>().fontSize = 15;
        unlockBtn.GetComponentInChildren<Text>().fontStyle = FontStyle.Bold;
        unlockBtn.image.color = new Color(0.0f, 0.85f, 1f);
        RectTransform unlockBtnRect = unlockBtnGo.GetComponent<RectTransform>();
        unlockBtnRect.anchorMin = new Vector2(0.28f, 0.33f);
        unlockBtnRect.anchorMax = new Vector2(0.72f, 0.41f);
        unlockBtnRect.sizeDelta = Vector2.zero;

        GameObject cancelBtnGo = DefaultControls.CreateButton(uiResources);
        Undo.RegisterCreatedObjectUndo(cancelBtnGo, "Create CancelButton");
        cancelBtnGo.name = "CancelButton";
        cancelBtnGo.transform.SetParent(lockPanel.transform, false);
        Button cancelBtn = cancelBtnGo.GetComponent<Button>();
        cancelBtn.GetComponentInChildren<Text>().text = "戻る (Back)";
        cancelBtn.GetComponentInChildren<Text>().font = defaultFont;
        cancelBtn.GetComponentInChildren<Text>().fontSize = 13;
        cancelBtn.image.color = new Color(0.2f, 0.2f, 0.3f);
        RectTransform cancelBtnRect = cancelBtnGo.GetComponent<RectTransform>();
        cancelBtnRect.anchorMin = new Vector2(0.74f, 0.03f);
        cancelBtnRect.anchorMax = new Vector2(0.94f, 0.08f);
        cancelBtnRect.sizeDelta = Vector2.zero;

        // (C) CastPanel
        GameObject castPanel = new GameObject("CastPanel");
        Undo.RegisterCreatedObjectUndo(castPanel, "Create CastPanel");
        castPanel.transform.SetParent(canvasGo.transform, false);
        RectTransform castPanelRect = castPanel.AddComponent<RectTransform>();
        castPanelRect.anchorMin = Vector2.zero;
        castPanelRect.anchorMax = Vector2.one;
        castPanelRect.sizeDelta = Vector2.zero;
        castPanel.SetActive(false);

        GameObject castTitleGo = new GameObject("CastTitle");
        Undo.RegisterCreatedObjectUndo(castTitleGo, "Create CastTitle");
        castTitleGo.transform.SetParent(castPanel.transform, false);
        Text castTitleText = castTitleGo.AddComponent<Text>();
        castTitleText.text = "GUEST LIST (CAST ONLY)";
        castTitleText.font = defaultFont;
        castTitleText.fontSize = 20;
        castTitleText.fontStyle = FontStyle.Bold;
        castTitleText.alignment = TextAnchor.MiddleCenter;
        castTitleText.color = new Color(0f, 0.94f, 1f);
        RectTransform castTitleRect = castTitleGo.GetComponent<RectTransform>();
        castTitleRect.anchorMin = new Vector2(0.05f, 0.89f);
        castTitleRect.anchorMax = new Vector2(0.95f, 0.97f);
        castTitleRect.sizeDelta = Vector2.zero;

        GameObject listTextGo = new GameObject("ListDisplayText");
        Undo.RegisterCreatedObjectUndo(listTextGo, "Create ListDisplayText");
        listTextGo.transform.SetParent(castPanel.transform, false);
        Text listText = listTextGo.AddComponent<Text>();
        listText.text = "名簿データを読み込み中...";
        listText.font = defaultFont;
        listText.fontSize = 13;
        listText.color = new Color(0.85f, 0.85f, 0.95f);
        listText.alignment = TextAnchor.UpperLeft;
        RectTransform listTextRect = listTextGo.GetComponent<RectTransform>();
        listTextRect.anchorMin = new Vector2(0.08f, 0.13f);
        listTextRect.anchorMax = new Vector2(0.92f, 0.86f);
        listTextRect.sizeDelta = Vector2.zero;

        GameObject closeBtnGo = DefaultControls.CreateButton(uiResources);
        Undo.RegisterCreatedObjectUndo(closeBtnGo, "Create CloseButton");
        closeBtnGo.name = "CloseButton";
        closeBtnGo.transform.SetParent(castPanel.transform, false);
        Button closeBtn = closeBtnGo.GetComponent<Button>();
        closeBtn.GetComponentInChildren<Text>().text = "閉じる (Lock)";
        closeBtn.GetComponentInChildren<Text>().font = defaultFont;
        closeBtn.GetComponentInChildren<Text>().fontSize = 14;
        closeBtn.GetComponentInChildren<Text>().fontStyle = FontStyle.Bold;
        closeBtn.image.color = new Color(1f, 0f, 0.4f);
        RectTransform closeBtnRect = closeBtnGo.GetComponent<RectTransform>();
        closeBtnRect.anchorMin = new Vector2(0.28f, 0.04f);
        closeBtnRect.anchorMax = new Vector2(0.72f, 0.10f);
        closeBtnRect.sizeDelta = Vector2.zero;

        // (D) StatusText
        GameObject statusTextGo = new GameObject("StatusDisplayText");
        Undo.RegisterCreatedObjectUndo(statusTextGo, "Create StatusDisplayText");
        statusTextGo.transform.SetParent(canvasGo.transform, false);
        Text statusText = statusTextGo.AddComponent<Text>();
        statusText.text = "システム起動完了";
        statusText.font = defaultFont;
        statusText.fontSize = 11;
        statusText.alignment = TextAnchor.MiddleCenter;
        statusText.color = new Color(0.5f, 0.5f, 0.6f);
        RectTransform statusTextRect = statusTextGo.GetComponent<RectTransform>();
        statusTextRect.anchorMin = new Vector2(0.05f, 0.005f);
        statusTextRect.anchorMax = new Vector2(0.95f, 0.04f);
        statusTextRect.sizeDelta = Vector2.zero;

        // 紐付け
        guestBook.nameInputField = nameInput;
        guestBook.commentInputField = commentInput;
        guestBook.listDisplayText = listText;
        guestBook.statusDisplayText = statusText;
        guestBook.passcodeInputField = passcodeInput;
        
        guestBook.guestPanel = guestPanel;
        guestBook.lockPanel = lockPanel;
        guestBook.castPanel = castPanel;

        RegisterUdonEvent(registerBtn, udonBehaviour, "OnRegisterClick");
        RegisterUdonEvent(lockBtn, udonBehaviour, "OnOpenLockClick");
        RegisterUdonEvent(unlockBtn, udonBehaviour, "OnUnlockClick");
        RegisterUdonEvent(cancelBtn, udonBehaviour, "OnLockClick");
        RegisterUdonEvent(closeBtn, udonBehaviour, "OnLockClick");

        SetLayerRecursive(canvasGo, LayerMask.NameToLayer("UI"));
    }

    private static void CreateSmartphoneStand(UdonBehaviour udonBehaviour, VRCGuestBook guestBook, GameObject packGo, GameObject phoneGo)
    {
        GameObject standRoot = new GameObject("VRCGuestBook_SmartphoneStand");
        Undo.RegisterCreatedObjectUndo(standRoot, "Create VRCGuestBook_SmartphoneStand");
        standRoot.transform.SetParent(packGo.transform, false);
        
        Shader safeShader = GetSafeShader();
        Material standMat = new Material(safeShader);
        standMat.color = new Color(0.18f, 0.18f, 0.22f);
        if (safeShader.name.Contains("Universal Render Pipeline")) {
            standMat.SetFloat("_Metallic", 0.5f);
            standMat.SetFloat("_Smoothness", 0.4f);
        } else {
            standMat.SetFloat("_Metallic", 0.5f);
            standMat.SetFloat("_Glossiness", 0.4f);
        }

        Material neonMat = new Material(safeShader);
        neonMat.color = new Color(0f, 0.94f, 1f);
        neonMat.EnableKeyword("_EMISSION");
        if (safeShader.name.Contains("Universal Render Pipeline")) {
            neonMat.SetColor("_EmissionColor", new Color(0f, 0.94f, 1f) * 1.5f);
        } else {
            neonMat.SetColor("_EmissionColor", new Color(0f, 0.47f, 0.5f));
        }

        Material metalMat = new Material(safeShader);
        metalMat.color = new Color(0.8f, 0.8f, 0.85f);
        if (safeShader.name.Contains("Universal Render Pipeline")) {
            metalMat.SetFloat("_Metallic", 0.95f);
            metalMat.SetFloat("_Smoothness", 0.8f);
        } else {
            metalMat.SetFloat("_Metallic", 0.95f);
            metalMat.SetFloat("_Glossiness", 0.8f);
        }

        // 1. 土台 (Base Plate - シリンダー)
        GameObject basePlate = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        basePlate.name = "Stand_Base";
        basePlate.transform.SetParent(standRoot.transform, false);
        basePlate.transform.localScale = new Vector3(0.12f, 0.01f, 0.12f);
        basePlate.transform.localPosition = new Vector3(0f, 0.005f, 0f); // 親（天板）から1cmの厚みで半分浮く
        basePlate.GetComponent<Renderer>().material = standMat;
        DestroyImmediate(basePlate.GetComponent<Collider>());

        // 2. 背もたれ支柱
        GameObject backPlate = GameObject.CreatePrimitive(PrimitiveType.Cube);
        backPlate.name = "Stand_Back";
        backPlate.transform.SetParent(standRoot.transform, false);
        backPlate.transform.localScale = new Vector3(0.08f, 0.12f, 0.01f);
        backPlate.transform.localPosition = new Vector3(0f, 0.06f, 0.01f);
        backPlate.transform.localRotation = Quaternion.Euler(20f, 0f, 0f);
        backPlate.GetComponent<Renderer>().material = standMat;
        DestroyImmediate(backPlate.GetComponent<Collider>());

        // 3. コネクタ
        GameObject connector = GameObject.CreatePrimitive(PrimitiveType.Cube);
        connector.name = "Stand_Connector";
        connector.transform.SetParent(standRoot.transform, false);
        connector.transform.localScale = new Vector3(0.015f, 0.01f, 0.005f);
        connector.transform.localPosition = new Vector3(0f, 0.01f, -0.002f);
        connector.transform.localRotation = Quaternion.Euler(20f, 0f, 0f);
        connector.GetComponent<Renderer>().material = metalMat;
        DestroyImmediate(connector.GetComponent<Collider>());

        // 4. ネオンバー
        GameObject lightBar = GameObject.CreatePrimitive(PrimitiveType.Cube);
        lightBar.name = "Stand_NeonLight";
        lightBar.transform.SetParent(standRoot.transform, false);
        lightBar.transform.localScale = new Vector3(0.05f, 0.002f, 0.002f);
        lightBar.transform.localPosition = new Vector3(0f, 0.012f, 0.003f);
        lightBar.transform.localRotation = Quaternion.Euler(20f, 0f, 0f);
        lightBar.GetComponent<Renderer>().material = neonMat;
        DestroyImmediate(lightBar.GetComponent<Collider>());

        BoxCollider boxCol = standRoot.AddComponent<BoxCollider>();
        boxCol.size = new Vector3(0.12f, 0.14f, 0.12f);
        boxCol.center = new Vector3(0f, 0.07f, 0f);

        UdonBehaviour btnUdon = standRoot.AddComponent<UdonBehaviour>();
        btnUdon.programSource = udonBehaviour.programSource;
        btnUdon.interactText = "スマホを取り出す/しまう";
        
        VRCGuestBook btnProxy = (VRCGuestBook)UdonSharpEditor.UdonSharpEditorUtility.GetProxyBehaviour(btnUdon);
        if (btnProxy != null)
        {
            Undo.RecordObject(btnProxy, "Set mainSystem of Stand");
            btnProxy.mainSystem = guestBook;
            UdonSharpEditor.UdonSharpEditorUtility.CopyProxyToUdon(btnProxy);
            EditorUtility.SetDirty(btnProxy);
            EditorUtility.SetDirty(btnUdon);
        }

        standRoot.layer = LayerMask.NameToLayer("Default");
    }

    private static void CreateCallButton(UdonBehaviour udonBehaviour, VRCGuestBook guestBook, GameObject packGo, GameObject tabletGo)
    {
        GameObject callBtnGo = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        Undo.RegisterCreatedObjectUndo(callBtnGo, "Create VRCGuestBook_CallButton");
        callBtnGo.name = "VRCGuestBook_CallButton";
        callBtnGo.transform.SetParent(packGo.transform, false);
        
        callBtnGo.transform.localPosition = new Vector3(0.25f, 0.015f, 0f);
        callBtnGo.transform.localScale = new Vector3(0.12f, 0.03f, 0.12f);

        Shader safeShader = GetSafeShader();
        Material btnMat = new Material(safeShader);
        btnMat.color = new Color(1f, 0f, 0.2f);
        btnMat.EnableKeyword("_EMISSION");
        btnMat.SetColor("_EmissionColor", new Color(0.4f, 0f, 0.08f));
        callBtnGo.GetComponent<Renderer>().material = btnMat;

        Collider col = callBtnGo.GetComponent<Collider>();
        if (col == null) col = callBtnGo.AddComponent<CapsuleCollider>();

        UdonBehaviour btnUdon = callBtnGo.AddComponent<UdonBehaviour>();
        btnUdon.programSource = udonBehaviour.programSource;
        btnUdon.interactText = "スマホを初期位置に戻す";
        
        VRCGuestBook btnProxy = (VRCGuestBook)UdonSharpEditor.UdonSharpEditorUtility.GetProxyBehaviour(btnUdon);
        if (btnProxy != null)
        {
            Undo.RecordObject(btnProxy, "Set mainSystem of Respawner");
            btnProxy.mainSystem = guestBook;
            UdonSharpEditor.UdonSharpEditorUtility.CopyProxyToUdon(btnProxy);
            EditorUtility.SetDirty(btnProxy);
            EditorUtility.SetDirty(btnUdon);
        }

        callBtnGo.layer = LayerMask.NameToLayer("Default");
    }

    private static void SetLayerRecursive(GameObject go, int layer)
    {
        go.layer = layer;
        foreach (Transform child in go.transform)
        {
            SetLayerRecursive(child.gameObject, layer);
        }
    }

    private static void RegisterUdonEvent(Button button, UdonBehaviour udonBehaviour, string eventName)
    {
        UnityEditor.Events.UnityEventTools.AddStringPersistentListener(
            button.onClick, 
            new UnityEngine.Events.UnityAction<string>(udonBehaviour.SendCustomEvent), 
            eventName
        );
    }

    private static Shader GetSafeShader()
    {
        Shader s = Shader.Find("Universal Render Pipeline/Lit");
        if (s == null) s = Shader.Find("Standard");
        if (s == null) s = Shader.Find("Legacy Shaders/Diffuse");
        if (s == null) s = Shader.Find("Diffuse");
        return s;
    }
}
#endif
