#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;
using UnityEngine.UI;
using VRC.Udon;
using VRC.SDK3.Components;
using UdonSharp;

public class VRCGuestBookSetupEditor : EditorWindow
{
    private string baseUrl = "https://test-sepia-three-75.vercel.app/api";
    private string bookId = "";
    private string passcode = "1234";
    private GameObject targetObject = null;
    private bool followUser = true; // 手元追従モード (ON:携帯スマホ化, OFF:卓上固定)
    private bool createCallButton = true; // スタンド/呼び出しボタンを生成

    [MenuItem("VRC Cast Companion/セットアップウィンドウ")]
    public static void ShowWindow()
    {
        VRCGuestBookSetupEditor window = GetWindow<VRCGuestBookSetupEditor>("VRC GuestBook Setup");
        window.minSize = new Vector2(400, 300);
        window.maxSize = new Vector2(500, 350);
        window.Show();
    }

    private void OnGUI()
    {
        GUILayout.Label("VRChat 顧客名簿システム セットアップ", EditorStyles.boldLabel);
        GUILayout.Space(10);

        baseUrl = EditorGUILayout.TextField("API Base URL", baseUrl);
        bookId = EditorGUILayout.TextField("Book ID (手帳ID)", bookId);
        passcode = EditorGUILayout.TextField("Passcode (暗証番号)", passcode);
        targetObject = (GameObject)EditorGUILayout.ObjectField("Target Tablet (手動配置用)", targetObject, typeof(GameObject), true);
        followUser = EditorGUILayout.Toggle("手元追従モード (携帯スマホ化)", followUser);
        createCallButton = EditorGUILayout.Toggle("充電スタンド/呼び出しボタン生成", createCallButton);

        GUILayout.Space(20);

        if (GUILayout.Button("自動セットアップを実行", GUILayout.Height(35)))
        {
            if (string.IsNullOrEmpty(bookId))
            {
                if (!EditorUtility.DisplayDialog("確認", "Book ID が入力されていません。セットアップ完了後にインスペクターから手動で設定することも可能です。このまま続行しますか？", "続行", "キャンセル"))
                {
                    return;
                }
            }
            
            ExecuteSetup();
            Close();
        }
    }

    private void ExecuteSetup()
    {
        // 複数配置と上書きの判別ロジック
        GameObject activeGo = Selection.activeGameObject;
        GameObject targetPack = null;
        if (activeGo != null)
        {
            Transform t = activeGo.transform;
            while (t != null)
            {
                if (t.gameObject.name.StartsWith("VRCGuestBook_Pack"))
                {
                    targetPack = t.gameObject;
                    break;
                }
                t = t.parent;
            }
        }

        UdonBehaviour udonBehaviour = null;
        VRCGuestBook guestBook = null;
        GameObject packGo = null;

        // UdonProgramAsset のロード
        string assetPath = "Assets/UdonSharp/VRCGuestBook_UdonProgramAsset.asset";
        UdonSharpProgramAsset programAsset = AssetDatabase.LoadAssetAtPath<UdonSharpProgramAsset>(assetPath);
        if (programAsset == null)
        {
            programAsset = ScriptableObject.CreateInstance<UdonSharpProgramAsset>();
            MonoScript csScript = AssetDatabase.LoadAssetAtPath<MonoScript>("Assets/UdonSharp/VRCGuestBook.cs");
            if (csScript != null)
            {
                programAsset.sourceCsScript = csScript;
                AssetDatabase.CreateAsset(programAsset, assetPath);
                AssetDatabase.SaveAssets();
                AssetDatabase.Refresh();
            }
            else
            {
                EditorUtility.DisplayDialog("エラー", "Assets/UdonSharp/VRCGuestBook.cs が見つかりませんでした。", "OK");
                return;
            }
        }

        if (targetPack != null)
        {
            packGo = targetPack;
            Transform systemT = packGo.transform.Find("VRCGuestBook_System");
            if (systemT != null)
            {
                udonBehaviour = systemT.GetComponent<UdonBehaviour>();
                guestBook = (VRCGuestBook)UdonSharpEditor.UdonSharpEditorUtility.GetProxyBehaviour(udonBehaviour);
            }
            
            Transform canvasT = packGo.transform.Find("VRCGuestBook_Canvas");
            if (canvasT != null)
            {
                Undo.DestroyObjectImmediate(canvasT.gameObject);
            }
            Transform callBtnT = packGo.transform.Find("VRCGuestBook_CallButton");
            if (callBtnT != null)
            {
                Undo.DestroyObjectImmediate(callBtnT.gameObject);
            }
            Transform standT = packGo.transform.Find("VRCGuestBook_SmartphoneStand");
            if (standT != null)
            {
                Undo.DestroyObjectImmediate(standT.gameObject);
            }
            
            Debug.Log("[VRCGuestBook] 既存の名簿パック " + packGo.name + " を上書き更新します。");
        }
        else
        {
            int count = 1;
            while (GameObject.Find("VRCGuestBook_Pack (" + count + ")") != null)
            {
                count++;
            }
            string packName = "VRCGuestBook_Pack (" + count + ")";
            packGo = new GameObject(packName);
            Undo.RegisterCreatedObjectUndo(packGo, "Create " + packName);
            
            Debug.Log("[VRCGuestBook] 新規名簿パック " + packName + " を作成します。");
        }

        // System オブジェクトのセットアップ
        if (udonBehaviour == null)
        {
            GameObject systemGo = new GameObject("VRCGuestBook_System");
            Undo.RegisterCreatedObjectUndo(systemGo, "Create VRCGuestBook_System");
            systemGo.transform.SetParent(packGo.transform, false);
            udonBehaviour = systemGo.AddComponent<UdonBehaviour>();
            udonBehaviour.programSource = programAsset;
            guestBook = (VRCGuestBook)UdonSharpEditor.UdonSharpEditorUtility.GetProxyBehaviour(udonBehaviour);
        }

        // URL Buffer オブジェクトのセットアップ
        VRCUrlInputField urlBuffer = null;
        Transform urlBufferT = packGo.transform.Find("VRCGuestBook_UrlBuffer");
        if (urlBufferT != null)
        {
            urlBuffer = urlBufferT.GetComponent<VRCUrlInputField>();
        }
        if (urlBuffer == null)
        {
            GameObject bufferGo = new GameObject("VRCGuestBook_UrlBuffer");
            Undo.RegisterCreatedObjectUndo(bufferGo, "Create VRCGuestBook_UrlBuffer");
            bufferGo.transform.SetParent(packGo.transform, false);
            urlBuffer = bufferGo.AddComponent<VRCUrlInputField>();
            bufferGo.AddComponent<InputField>();
            bufferGo.SetActive(false);
        }

        // スマートフォン筐体のセットアップ
        GameObject phoneGo = null;
        if (targetObject != null)
        {
            phoneGo = targetObject;
        }
        else
        {
            Transform existingPhone = packGo.transform.Find("VRCGuestBook_Smartphone");
            if (existingPhone != null)
            {
                // お嬢のスマホ筐体を最新のリッチデザインにするため、既存のものは削除して再ビルドします
                Undo.DestroyObjectImmediate(existingPhone.gameObject);
            }

            // 角丸スマートフォン筐体の動的組み立て (横 8cm x 縦 16cm x 厚さ 8mm)
            phoneGo = new GameObject("VRCGuestBook_Smartphone");
            Undo.RegisterCreatedObjectUndo(phoneGo, "Create VRCGuestBook_Smartphone");
            phoneGo.name = "VRCGuestBook_Smartphone";
            phoneGo.transform.SetParent(packGo.transform, false);
            phoneGo.transform.localPosition = new Vector3(0f, 1.22f, 0.8f);
            phoneGo.transform.localRotation = Quaternion.Euler(20f, 0f, 0f); // 初期状態でスタンドにフィットする傾き

            // マテリアルのセットアップ
            Shader safeShader = GetSafeShader();
            Material bodyMat = new Material(safeShader);
            bodyMat.color = new Color(0.12f, 0.12f, 0.15f); // 高級感のあるダークグレー
            if (safeShader.name.Contains("Universal Render Pipeline")) {
                bodyMat.SetFloat("_Metallic", 0.9f);
                bodyMat.SetFloat("_Smoothness", 0.7f); // URPではGlossinessの代わりにSmoothness
            } else {
                bodyMat.SetFloat("_Metallic", 0.9f);
                bodyMat.SetFloat("_Glossiness", 0.7f);
            }

            Material screenMat = new Material(safeShader);
            screenMat.color = new Color(0.02f, 0.02f, 0.03f); // 漆黒の光沢ガラス画面
            if (safeShader.name.Contains("Universal Render Pipeline")) {
                screenMat.SetFloat("_Metallic", 0.1f);
                screenMat.SetFloat("_Smoothness", 0.95f);
            } else {
                screenMat.SetFloat("_Metallic", 0.1f);
                screenMat.SetFloat("_Glossiness", 0.95f);
            }

            Material metalMat = new Material(safeShader);
            metalMat.color = new Color(0.8f, 0.8f, 0.85f); // レシーバーなどの金属シルバー
            if (safeShader.name.Contains("Universal Render Pipeline")) {
                metalMat.SetFloat("_Metallic", 0.95f);
                metalMat.SetFloat("_Smoothness", 0.8f);
            } else {
                metalMat.SetFloat("_Metallic", 0.95f);
                metalMat.SetFloat("_Glossiness", 0.8f);
            }

            float w = 0.08f;
            float h = 0.16f;
            float d = 0.008f;
            float r = 0.008f; // 角丸の半径

            // 中央プレート
            GameObject centerCube = GameObject.CreatePrimitive(PrimitiveType.Cube);
            centerCube.name = "Body_Center";
            centerCube.transform.SetParent(phoneGo.transform, false);
            centerCube.transform.localScale = new Vector3(w - r * 2f, h, d);
            centerCube.GetComponent<Renderer>().material = bodyMat;
            DestroyImmediate(centerCube.GetComponent<Collider>());

            // 左右サイドプレート
            GameObject leftCube = GameObject.CreatePrimitive(PrimitiveType.Cube);
            leftCube.name = "Body_Left";
            leftCube.transform.SetParent(phoneGo.transform, false);
            leftCube.transform.localPosition = new Vector3(-(w / 2f - r / 2f), 0f, 0f);
            leftCube.transform.localScale = new Vector3(r, h - r * 2f, d);
            leftCube.GetComponent<Renderer>().material = bodyMat;
            DestroyImmediate(leftCube.GetComponent<Collider>());

            GameObject rightCube = GameObject.CreatePrimitive(PrimitiveType.Cube);
            rightCube.name = "Body_Right";
            rightCube.transform.SetParent(phoneGo.transform, false);
            rightCube.transform.localPosition = new Vector3((w / 2f - r / 2f), 0f, 0f);
            rightCube.transform.localScale = new Vector3(r, h - r * 2f, d);
            rightCube.GetComponent<Renderer>().material = bodyMat;
            DestroyImmediate(rightCube.GetComponent<Collider>());

            // 四隅のコーナー (シリンダー)
            string[] cornerNames = { "Corner_TL", "Corner_TR", "Corner_BL", "Corner_BR" };
            Vector3[] cornerPositions = {
                new Vector3(-(w / 2f - r), (h / 2f - r), 0f),
                new Vector3((w / 2f - r), (h / 2f - r), 0f),
                new Vector3(-(w / 2f - r), -(h / 2f - r), 0f),
                new Vector3((w / 2f - r), -(h / 2f - r), 0f)
            };
            for (int i = 0; i < 4; i++)
            {
                GameObject corner = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
                corner.name = cornerNames[i];
                corner.transform.SetParent(phoneGo.transform, false);
                corner.transform.localPosition = cornerPositions[i];
                corner.transform.localRotation = Quaternion.Euler(90f, 0f, 0f);
                corner.transform.localScale = new Vector3(r * 2f, d / 2f, r * 2f);
                corner.GetComponent<Renderer>().material = bodyMat;
                DestroyImmediate(corner.GetComponent<Collider>());
            }

            // ディスプレイ画面
            GameObject screen = GameObject.CreatePrimitive(PrimitiveType.Cube);
            screen.name = "Display_Screen";
            screen.transform.SetParent(phoneGo.transform, false);
            screen.transform.localPosition = new Vector3(0f, 0f, d / 2f + 0.0002f);
            screen.transform.localScale = new Vector3(w - 0.004f, h - 0.012f, 0.0005f); // ベゼルを残して少し薄く配置
            screen.GetComponent<Renderer>().material = screenMat;
            DestroyImmediate(screen.GetComponent<Collider>());

            // スピーカー穴
            GameObject speaker = GameObject.CreatePrimitive(PrimitiveType.Cube);
            speaker.name = "Speaker_Slit";
            speaker.transform.SetParent(phoneGo.transform, false);
            speaker.transform.localPosition = new Vector3(0f, h / 2f - 0.005f, d / 2f + 0.0003f);
            speaker.transform.localScale = new Vector3(0.015f, 0.0015f, 0.0002f);
            speaker.GetComponent<Renderer>().material = metalMat;
            DestroyImmediate(speaker.GetComponent<Collider>());

            // コライダーアタッチ
            BoxCollider boxCol = phoneGo.AddComponent<BoxCollider>();
            boxCol.size = new Vector3(w, h, d);

            if (!followUser)
            {
                Rigidbody rb = phoneGo.AddComponent<Rigidbody>();
                rb.mass = 0.5f;
                rb.useGravity = true;

                System.Type pickupType = System.Type.GetType("VRC.SDKBase.VRC_Pickup, VRCSDKBase");
                if (pickupType != null)
                {
                    phoneGo.AddComponent(pickupType);
                }
            }
            else
            {
                boxCol.isTrigger = true;
            }
        }

        if (guestBook != null)
        {
            Undo.RecordObject(guestBook, "VRCGuestBook Setup Reference");
            guestBook.urlBufferInputField = urlBuffer;
            guestBook.baseUrl = new VRC.SDKBase.VRCUrl(baseUrl);
            guestBook.bookId = bookId;
            guestBook.passcode = passcode;
            guestBook.tabletObject = phoneGo; // スマホ筐体

            // UI Canvasの自動生成とアタッチ
            CreateUI(udonBehaviour, guestBook, packGo, phoneGo);

            // スタンド、または呼び出しボタンの自動生成
            if (createCallButton)
            {
                if (followUser)
                {
                    // 携帯スマホ用の「充電スタンド（出現トグル）」を自動生成
                    CreateSmartphoneStand(udonBehaviour, guestBook, packGo, phoneGo);
                }
                else
                {
                    // 固定設置用の「呼び出しボタン」を自動生成
                    CreateCallButton(udonBehaviour, guestBook, packGo, phoneGo);
                }
            }

            UdonSharpEditor.UdonSharpEditorUtility.CopyProxyToUdon(guestBook);
            EditorUtility.SetDirty(guestBook);
            EditorUtility.SetDirty(udonBehaviour);
            
            UnityEditor.SceneManagement.EditorSceneManager.MarkSceneDirty(UnityEngine.SceneManagement.SceneManager.GetActiveScene());
            
            EditorUtility.DisplayDialog("セットアップ完了", "携帯型スマートフォン名簿システムの自動設置が完了しました。\n\n・スマホ筐体 (横8cm x 縦16cm x 厚さ8mm) を自動構築しました。\n・Canvas解像度を縦長 (450x800) に最適化したネオンUIを自動配置しました。\n・出勤キャスト選択UI、および手元/カメラへのLateUpdate追従システムを紐付けました。\n・スマホの出現をトグルする3D充電スタンドを自動配置しました。", "OK");
        }
    }

    private static void CreateUI(UdonBehaviour udonBehaviour, VRCGuestBook guestBook, GameObject packGo, GameObject phoneGo)
    {
        GameObject canvasGo = new GameObject("VRCGuestBook_Canvas");
        Undo.RegisterCreatedObjectUndo(canvasGo, "Create VRCGuestBook_Canvas");
        canvasGo.transform.SetParent(packGo.transform, false);
        
        Canvas canvas = canvasGo.AddComponent<Canvas>();
        canvas.renderMode = RenderMode.WorldSpace;
        canvasGo.AddComponent<CanvasScaler>();
        canvasGo.AddComponent<GraphicRaycaster>();
        
        canvasGo.AddComponent<VRC.SDKBase.VRC_UiShape>();
        // ※手動コライダーは追加しない (VRC_UiShapeの自動コライダーに任せ、クリックの遮断を防ぐ)

        // スマホの表面（厚さ8mmの表面、浮かせ幅 0.0045m）に吸着
        canvasGo.transform.position = phoneGo.transform.position + phoneGo.transform.up * 0.0045f;
        canvasGo.transform.rotation = phoneGo.transform.rotation;
        // スケール: 450px -> 0.0765m (スマホ幅8cmに収まる)
        canvasGo.transform.localScale = new Vector3(0.00017f, 0.00017f, 1f);

        RectTransform canvasRect = canvasGo.GetComponent<RectTransform>();
        canvasRect.sizeDelta = new Vector2(450f, 800f);
        guestBook.canvasObject = canvasGo; // 追従対象としてアタッチ

        // 背景
        GameObject bgGo = new GameObject("Background");
        Undo.RegisterCreatedObjectUndo(bgGo, "Create Background");
        bgGo.transform.SetParent(canvasGo.transform, false);
        Image bgImg = bgGo.AddComponent<Image>();
        bgImg.color = new Color(0.04f, 0.04f, 0.08f, 0.98f);
        RectTransform bgRect = bgGo.GetComponent<RectTransform>();
        bgRect.anchorMin = Vector2.zero;
        bgRect.anchorMax = Vector2.one;
        bgRect.sizeDelta = Vector2.zero;

        Font defaultFont = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
        DefaultControls.Resources uiResources = new DefaultControls.Resources();

        // (A) GuestPanel (縦型スマホ用に最適化)
        GameObject guestPanel = new GameObject("GuestPanel");
        Undo.RegisterCreatedObjectUndo(guestPanel, "Create GuestPanel");
        guestPanel.transform.SetParent(canvasGo.transform, false);
        RectTransform guestRect = guestPanel.AddComponent<RectTransform>();
        guestRect.anchorMin = Vector2.zero;
        guestRect.anchorMax = Vector2.one;
        guestRect.sizeDelta = Vector2.zero;

        // タイトル
        GameObject titleGo = new GameObject("Title");
        Undo.RegisterCreatedObjectUndo(titleGo, "Create Title");
        titleGo.transform.SetParent(guestPanel.transform, false);
        Text titleText = titleGo.AddComponent<Text>();
        titleText.text = "GUEST BOOK";
        titleText.font = defaultFont;
        titleText.fontSize = 24;
        titleText.fontStyle = FontStyle.Bold;
        titleText.alignment = TextAnchor.MiddleCenter;
        titleText.color = new Color(0f, 0.94f, 1f);
        RectTransform titleRect = titleGo.GetComponent<RectTransform>();
        titleRect.anchorMin = new Vector2(0.05f, 0.86f);
        titleRect.anchorMax = new Vector2(0.95f, 0.94f);
        titleRect.sizeDelta = Vector2.zero;

        // お名前ラベルとInputField
        GameObject nameLabelGo = new GameObject("NameLabel");
        Undo.RegisterCreatedObjectUndo(nameLabelGo, "Create NameLabel");
        nameLabelGo.transform.SetParent(guestPanel.transform, false);
        Text nameLabel = nameLabelGo.AddComponent<Text>();
        nameLabel.text = "お名前 (Your Name)";
        nameLabel.font = defaultFont;
        nameLabel.fontSize = 14;
        nameLabel.color = new Color(0.8f, 0.8f, 0.9f);
        RectTransform nameLabelRect = nameLabelGo.GetComponent<RectTransform>();
        nameLabelRect.anchorMin = new Vector2(0.12f, 0.77f);
        nameLabelRect.anchorMax = new Vector2(0.88f, 0.82f);
        nameLabelRect.sizeDelta = Vector2.zero;

        GameObject nameInputGo = DefaultControls.CreateInputField(uiResources);
        Undo.RegisterCreatedObjectUndo(nameInputGo, "Create NameInputField");
        nameInputGo.name = "NameInputField";
        nameInputGo.transform.SetParent(guestPanel.transform, false);
        InputField nameInput = nameInputGo.GetComponent<InputField>();
        nameInput.textComponent.font = defaultFont;
        nameInput.textComponent.fontSize = 15;
        nameInput.textComponent.color = Color.white;
        nameInput.placeholder.GetComponent<Text>().font = defaultFont;
        nameInput.placeholder.GetComponent<Text>().fontSize = 13;
        nameInput.placeholder.GetComponent<Text>().text = "お名前を入力しておくれ...";
        nameInput.placeholder.GetComponent<Text>().color = new Color(0.5f, 0.5f, 0.6f);
        RectTransform nameInputRect = nameInputGo.GetComponent<RectTransform>();
        nameInputRect.anchorMin = new Vector2(0.12f, 0.69f);
        nameInputRect.anchorMax = new Vector2(0.88f, 0.75f);
        nameInputRect.sizeDelta = Vector2.zero;

        // 出勤キャスト選択 UI
        GameObject castLabelGo = new GameObject("CastSelectLabel");
        Undo.RegisterCreatedObjectUndo(castLabelGo, "Create CastSelectLabel");
        castLabelGo.transform.SetParent(guestPanel.transform, false);
        Text castLabel = castLabelGo.AddComponent<Text>();
        castLabel.text = "出勤キャスト (クリックで自動入力)";
        castLabel.font = defaultFont;
        castLabel.fontSize = 13;
        castLabel.color = new Color(0.7f, 0.7f, 0.8f);
        RectTransform castLabelRect = castLabelGo.GetComponent<RectTransform>();
        castLabelRect.anchorMin = new Vector2(0.12f, 0.61f);
        castLabelRect.anchorMax = new Vector2(0.88f, 0.65f);
        castLabelRect.sizeDelta = Vector2.zero;

        // スマホ用 2列配置のキャスト選択ボタン群
        GameObject[] castBtns = new GameObject[5];
        Text[] castTexts = new Text[5];
        for (int i = 0; i < 5; i++)
        {
            GameObject castBtnGo = DefaultControls.CreateButton(uiResources);
            castBtnGo.name = "CastButton_" + i;
            Undo.RegisterCreatedObjectUndo(castBtnGo, "Create CastButton_" + i);
            castBtnGo.transform.SetParent(guestPanel.transform, false);
            
            Button btn = castBtnGo.GetComponent<Button>();
            Text txt = btn.GetComponentInChildren<Text>();
            txt.text = "キャスト " + (i + 1);
            txt.font = defaultFont;
            txt.fontSize = 11;
            txt.color = Color.white;
            btn.image.color = new Color(0.15f, 0.15f, 0.25f);
            
            RectTransform btnRect = castBtnGo.GetComponent<RectTransform>();
            if (i == 0) { btnRect.anchorMin = new Vector2(0.12f, 0.53f); btnRect.anchorMax = new Vector2(0.48f, 0.58f); }
            else if (i == 1) { btnRect.anchorMin = new Vector2(0.52f, 0.53f); btnRect.anchorMax = new Vector2(0.88f, 0.58f); }
            else if (i == 2) { btnRect.anchorMin = new Vector2(0.12f, 0.46f); btnRect.anchorMax = new Vector2(0.48f, 0.51f); }
            else if (i == 3) { btnRect.anchorMin = new Vector2(0.52f, 0.46f); btnRect.anchorMax = new Vector2(0.88f, 0.51f); }
            else { btnRect.anchorMin = new Vector2(0.32f, 0.39f); btnRect.anchorMax = new Vector2(0.68f, 0.44f); }
            btnRect.sizeDelta = Vector2.zero;
            
            castBtns[i] = castBtnGo;
            castTexts[i] = txt;
            
            RegisterUdonEvent(btn, udonBehaviour, "OnCastClick" + i);
            castBtnGo.SetActive(false); // 初期非アクティブ
        }
        guestBook.castButtons = castBtns;
        guestBook.castNameTexts = castTexts;

        // コメントラベルとInputField
        GameObject commentLabelGo = new GameObject("CommentLabel");
        Undo.RegisterCreatedObjectUndo(commentLabelGo, "Create CommentLabel");
        commentLabelGo.transform.SetParent(guestPanel.transform, false);
        Text commentLabel = commentLabelGo.AddComponent<Text>();
        commentLabel.text = "ひとことコメント (Comment)";
        commentLabel.font = defaultFont;
        commentLabel.fontSize = 14;
        commentLabel.color = new Color(0.8f, 0.8f, 0.9f);
        RectTransform commentLabelRect = commentLabelGo.GetComponent<RectTransform>();
        commentLabelRect.anchorMin = new Vector2(0.12f, 0.32f);
        commentLabelRect.anchorMax = new Vector2(0.88f, 0.37f);
        commentLabelRect.sizeDelta = Vector2.zero;

        GameObject commentInputGo = DefaultControls.CreateInputField(uiResources);
        Undo.RegisterCreatedObjectUndo(commentInputGo, "Create CommentInputField");
        commentInputGo.name = "CommentInputField";
        commentInputGo.transform.SetParent(guestPanel.transform, false);
        InputField commentInput = commentInputGo.GetComponent<InputField>();
        commentInput.textComponent.font = defaultFont;
        commentInput.textComponent.fontSize = 15;
        commentInput.textComponent.color = Color.white;
        commentInput.placeholder.GetComponent<Text>().font = defaultFont;
        commentInput.placeholder.GetComponent<Text>().fontSize = 13;
        commentInput.placeholder.GetComponent<Text>().text = "コメントを入力しておくれ...";
        commentInput.placeholder.GetComponent<Text>().color = new Color(0.5f, 0.5f, 0.6f);
        RectTransform commentInputRect = commentInputGo.GetComponent<RectTransform>();
        commentInputRect.anchorMin = new Vector2(0.12f, 0.22f);
        commentInputRect.anchorMax = new Vector2(0.88f, 0.29f);
        commentInputRect.sizeDelta = Vector2.zero;

        // 記名ボタン
        GameObject registerBtnGo = DefaultControls.CreateButton(uiResources);
        Undo.RegisterCreatedObjectUndo(registerBtnGo, "Create RegisterButton");
        registerBtnGo.name = "RegisterButton";
        registerBtnGo.transform.SetParent(guestPanel.transform, false);
        Button registerBtn = registerBtnGo.GetComponent<Button>();
        registerBtn.GetComponentInChildren<Text>().text = "記名する (Send)";
        registerBtn.GetComponentInChildren<Text>().font = defaultFont;
        registerBtn.GetComponentInChildren<Text>().fontSize = 16;
        registerBtn.GetComponentInChildren<Text>().fontStyle = FontStyle.Bold;
        registerBtn.GetComponentInChildren<Text>().color = Color.white;
        registerBtn.image.color = new Color(0.6f, 0f, 1f);
        RectTransform registerBtnRect = registerBtnGo.GetComponent<RectTransform>();
        registerBtnRect.anchorMin = new Vector2(0.22f, 0.10f);
        registerBtnRect.anchorMax = new Vector2(0.78f, 0.17f);
        registerBtnRect.sizeDelta = Vector2.zero;

        // ロックボタン (🔑)
        GameObject lockBtnGo = DefaultControls.CreateButton(uiResources);
        Undo.RegisterCreatedObjectUndo(lockBtnGo, "Create LockButton");
        lockBtnGo.name = "LockButton";
        lockBtnGo.transform.SetParent(guestPanel.transform, false);
        Button lockBtn = lockBtnGo.GetComponent<Button>();
        lockBtn.GetComponentInChildren<Text>().text = "🔑";
        lockBtn.GetComponentInChildren<Text>().font = defaultFont;
        lockBtn.GetComponentInChildren<Text>().fontSize = 15;
        lockBtn.image.color = new Color(0.15f, 0.15f, 0.25f);
        RectTransform lockBtnRect = lockBtnGo.GetComponent<RectTransform>();
        lockBtnRect.anchorMin = new Vector2(0.84f, 0.89f);
        lockBtnRect.anchorMax = new Vector2(0.94f, 0.95f);
        lockBtnRect.sizeDelta = Vector2.zero;


        // (B) LockPanel (パスコード画面)
        GameObject lockPanel = new GameObject("LockPanel");
        Undo.RegisterCreatedObjectUndo(lockPanel, "Create LockPanel");
        lockPanel.transform.SetParent(canvasGo.transform, false);
        RectTransform lockPanelRect = lockPanel.AddComponent<RectTransform>();
        lockPanelRect.anchorMin = Vector2.zero;
        lockPanelRect.anchorMax = Vector2.one;
        lockPanelRect.sizeDelta = Vector2.zero;
        lockPanel.SetActive(false);

        GameObject lockTitleGo = new GameObject("LockTitle");
        Undo.RegisterCreatedObjectUndo(lockTitleGo, "Create LockTitle");
        lockTitleGo.transform.SetParent(lockPanel.transform, false);
        Text lockTitleText = lockTitleGo.AddComponent<Text>();
        lockTitleText.text = "CAST AREA LOCK";
        lockTitleText.font = defaultFont;
        lockTitleText.fontSize = 22;
        lockTitleText.fontStyle = FontStyle.Bold;
        lockTitleText.alignment = TextAnchor.MiddleCenter;
        lockTitleText.color = new Color(1f, 0f, 0.4f);
        RectTransform lockTitleRect = lockTitleGo.GetComponent<RectTransform>();
        lockTitleRect.anchorMin = new Vector2(0.05f, 0.78f);
        lockTitleRect.anchorMax = new Vector2(0.95f, 0.88f);
        lockTitleRect.sizeDelta = Vector2.zero;

        GameObject passcodeLabelGo = new GameObject("PasscodeLabel");
        Undo.RegisterCreatedObjectUndo(passcodeLabelGo, "Create PasscodeLabel");
        passcodeLabelGo.transform.SetParent(lockPanel.transform, false);
        Text passcodeLabel = passcodeLabelGo.AddComponent<Text>();
        passcodeLabel.text = "暗証番号を入力してください";
        passcodeLabel.font = defaultFont;
        passcodeLabel.fontSize = 13;
        passcodeLabel.alignment = TextAnchor.MiddleCenter;
        passcodeLabel.color = new Color(0.8f, 0.8f, 0.9f);
        RectTransform passcodeLabelRect = passcodeLabelGo.GetComponent<RectTransform>();
        passcodeLabelRect.anchorMin = new Vector2(0.05f, 0.63f);
        passcodeLabelRect.anchorMax = new Vector2(0.95f, 0.69f);
        passcodeLabelRect.sizeDelta = Vector2.zero;

        GameObject passcodeInputGo = DefaultControls.CreateInputField(uiResources);
        Undo.RegisterCreatedObjectUndo(passcodeInputGo, "Create PasscodeInputField");
        passcodeInputGo.name = "PasscodeInputField";
        passcodeInputGo.transform.SetParent(lockPanel.transform, false);
        InputField passcodeInput = passcodeInputGo.GetComponent<InputField>();
        passcodeInput.textComponent.font = defaultFont;
        passcodeInput.textComponent.fontSize = 18;
        passcodeInput.textComponent.color = Color.white;
        passcodeInput.textComponent.alignment = TextAnchor.MiddleCenter;
        passcodeInput.inputType = InputField.InputType.Password;
        passcodeInput.placeholder.GetComponent<Text>().font = defaultFont;
        passcodeInput.placeholder.GetComponent<Text>().fontSize = 13;
        passcodeInput.placeholder.GetComponent<Text>().text = "Passcode...";
        passcodeInput.placeholder.GetComponent<Text>().color = new Color(0.5f, 0.5f, 0.6f);
        passcodeInput.placeholder.GetComponent<Text>().alignment = TextAnchor.MiddleCenter;
        RectTransform passcodeInputRect = passcodeInputGo.GetComponent<RectTransform>();
        passcodeInputRect.anchorMin = new Vector2(0.25f, 0.49f);
        passcodeInputRect.anchorMax = new Vector2(0.75f, 0.57f);
        passcodeInputRect.sizeDelta = Vector2.zero;

        GameObject unlockBtnGo = DefaultControls.CreateButton(uiResources);
        Undo.RegisterCreatedObjectUndo(unlockBtnGo, "Create UnlockButton");
        unlockBtnGo.name = "UnlockButton";
        unlockBtnGo.transform.SetParent(lockPanel.transform, false);
        Button unlockBtn = unlockBtnGo.GetComponent<Button>();
        unlockBtn.GetComponentInChildren<Text>().text = "解除 (Unlock)";
        unlockBtn.GetComponentInChildren<Text>().font = defaultFont;
        unlockBtn.GetComponentInChildren<Text>().fontSize = 15;
        unlockBtn.GetComponentInChildren<Text>().fontStyle = FontStyle.Bold;
        unlockBtn.image.color = new Color(0.0f, 0.85f, 1f);
        RectTransform unlockBtnRect = unlockBtnGo.GetComponent<RectTransform>();
        unlockBtnRect.anchorMin = new Vector2(0.28f, 0.33f);
        unlockBtnRect.anchorMax = new Vector2(0.72f, 0.41f);
        unlockBtnRect.sizeDelta = Vector2.zero;

        GameObject cancelBtnGo = DefaultControls.CreateButton(uiResources);
        Undo.RegisterCreatedObjectUndo(cancelBtnGo, "Create CancelButton");
        cancelBtnGo.name = "CancelButton";
        cancelBtnGo.transform.SetParent(lockPanel.transform, false);
        Button cancelBtn = cancelBtnGo.GetComponent<Button>();
        cancelBtn.GetComponentInChildren<Text>().text = "戻る (Back)";
        cancelBtn.GetComponentInChildren<Text>().font = defaultFont;
        cancelBtn.GetComponentInChildren<Text>().fontSize = 13;
        cancelBtn.image.color = new Color(0.2f, 0.2f, 0.3f);
        RectTransform cancelBtnRect = cancelBtnGo.GetComponent<RectTransform>();
        cancelBtnRect.anchorMin = new Vector2(0.74f, 0.03f);
        cancelBtnRect.anchorMax = new Vector2(0.94f, 0.08f);
        cancelBtnRect.sizeDelta = Vector2.zero;


        // (C) CastPanel (名簿閲覧画面)
        GameObject castPanel = new GameObject("CastPanel");
        Undo.RegisterCreatedObjectUndo(castPanel, "Create CastPanel");
        castPanel.transform.SetParent(canvasGo.transform, false);
        RectTransform castPanelRect = castPanel.AddComponent<RectTransform>();
        castPanelRect.anchorMin = Vector2.zero;
        castPanelRect.anchorMax = Vector2.one;
        castPanelRect.sizeDelta = Vector2.zero;
        castPanel.SetActive(false);

        GameObject castTitleGo = new GameObject("CastTitle");
        Undo.RegisterCreatedObjectUndo(castTitleGo, "Create CastTitle");
        castTitleGo.transform.SetParent(castPanel.transform, false);
        Text castTitleText = castTitleGo.AddComponent<Text>();
        castTitleText.text = "GUEST LIST (CAST ONLY)";
        castTitleText.font = defaultFont;
        castTitleText.fontSize = 20;
        castTitleText.fontStyle = FontStyle.Bold;
        castTitleText.alignment = TextAnchor.MiddleCenter;
        castTitleText.color = new Color(0f, 0.94f, 1f);
        RectTransform castTitleRect = castTitleGo.GetComponent<RectTransform>();
        castTitleRect.anchorMin = new Vector2(0.05f, 0.89f);
        castTitleRect.anchorMax = new Vector2(0.95f, 0.97f);
        castTitleRect.sizeDelta = Vector2.zero;

        GameObject listTextGo = new GameObject("ListDisplayText");
        Undo.RegisterCreatedObjectUndo(listTextGo, "Create ListDisplayText");
        listTextGo.transform.SetParent(castPanel.transform, false);
        Text listText = listTextGo.AddComponent<Text>();
        listText.text = "名簿データを読み込み中...";
        listText.font = defaultFont;
        listText.fontSize = 13;
        listText.color = new Color(0.85f, 0.85f, 0.95f);
        listText.alignment = TextAnchor.UpperLeft;
        RectTransform listTextRect = listTextGo.GetComponent<RectTransform>();
        listTextRect.anchorMin = new Vector2(0.08f, 0.13f);
        listTextRect.anchorMax = new Vector2(0.92f, 0.86f);
        listTextRect.sizeDelta = Vector2.zero;

        GameObject closeBtnGo = DefaultControls.CreateButton(uiResources);
        Undo.RegisterCreatedObjectUndo(closeBtnGo, "Create CloseButton");
        closeBtnGo.name = "CloseButton";
        closeBtnGo.transform.SetParent(castPanel.transform, false);
        Button closeBtn = closeBtnGo.GetComponent<Button>();
        closeBtn.GetComponentInChildren<Text>().text = "閉じる (Lock)";
        closeBtn.GetComponentInChildren<Text>().font = defaultFont;
        closeBtn.GetComponentInChildren<Text>().fontSize = 14;
        closeBtn.GetComponentInChildren<Text>().fontStyle = FontStyle.Bold;
        closeBtn.image.color = new Color(1f, 0f, 0.4f);
        RectTransform closeBtnRect = closeBtnGo.GetComponent<RectTransform>();
        closeBtnRect.anchorMin = new Vector2(0.28f, 0.04f);
        closeBtnRect.anchorMax = new Vector2(0.72f, 0.10f);
        closeBtnRect.sizeDelta = Vector2.zero;

        // (D) StatusText
        GameObject statusTextGo = new GameObject("StatusDisplayText");
        Undo.RegisterCreatedObjectUndo(statusTextGo, "Create StatusDisplayText");
        statusTextGo.transform.SetParent(canvasGo.transform, false);
        Text statusText = statusTextGo.AddComponent<Text>();
        statusText.text = "システム起動完了";
        statusText.font = defaultFont;
        statusText.fontSize = 11;
        statusText.alignment = TextAnchor.MiddleCenter;
        statusText.color = new Color(0.5f, 0.5f, 0.6f);
        RectTransform statusTextRect = statusTextGo.GetComponent<RectTransform>();
        statusTextRect.anchorMin = new Vector2(0.05f, 0.005f);
        statusTextRect.anchorMax = new Vector2(0.95f, 0.04f);
        statusTextRect.sizeDelta = Vector2.zero;

        // 変数参照の紐付け
        guestBook.nameInputField = nameInput;
        guestBook.commentInputField = commentInput;
        guestBook.listDisplayText = listText;
        guestBook.statusDisplayText = statusText;
        guestBook.passcodeInputField = passcodeInput;
        
        guestBook.guestPanel = guestPanel;
        guestBook.lockPanel = lockPanel;
        guestBook.castPanel = castPanel;

        RegisterUdonEvent(registerBtn, udonBehaviour, "OnRegisterClick");
        RegisterUdonEvent(lockBtn, udonBehaviour, "OnOpenLockClick");
        RegisterUdonEvent(unlockBtn, udonBehaviour, "OnUnlockClick");
        RegisterUdonEvent(cancelBtn, udonBehaviour, "OnLockClick");
        RegisterUdonEvent(closeBtn, udonBehaviour, "OnLockClick");

        SetLayerRecursive(canvasGo, LayerMask.NameToLayer("UI"));
    }

    private static void CreateSmartphoneStand(UdonBehaviour udonBehaviour, VRCGuestBook guestBook, GameObject packGo, GameObject phoneGo)
    {
        // 携帯スマホ出現トグルのための「充電スタンド（3Dオブジェクト）」を自動生成
        GameObject standRoot = new GameObject("VRCGuestBook_SmartphoneStand");
        Undo.RegisterCreatedObjectUndo(standRoot, "Create VRCGuestBook_SmartphoneStand");
        standRoot.transform.SetParent(packGo.transform, false);
        
        // スタンドのカラーアタッチ用マテリアル
        Shader safeShader = GetSafeShader();
        Material standMat = new Material(safeShader);
        standMat.color = new Color(0.18f, 0.18f, 0.22f); // マットなチャコールグレー
        if (safeShader.name.Contains("Universal Render Pipeline")) {
            standMat.SetFloat("_Metallic", 0.5f);
            standMat.SetFloat("_Smoothness", 0.4f);
        } else {
            standMat.SetFloat("_Metallic", 0.5f);
            standMat.SetFloat("_Glossiness", 0.4f);
        }

        Material neonMat = new Material(safeShader);
        neonMat.color = new Color(0f, 0.94f, 1f); // サイアンのネオン
        neonMat.EnableKeyword("_EMISSION");
        if (safeShader.name.Contains("Universal Render Pipeline")) {
            neonMat.SetColor("_EmissionColor", new Color(0f, 0.94f, 1f) * 1.5f); // URPでの発光強度調整
        } else {
            neonMat.SetColor("_EmissionColor", new Color(0f, 0.47f, 0.5f)); // 自発光
        }

        Material metalMat = new Material(safeShader);
        metalMat.color = new Color(0.8f, 0.8f, 0.85f);
        if (safeShader.name.Contains("Universal Render Pipeline")) {
            metalMat.SetFloat("_Metallic", 0.95f);
            metalMat.SetFloat("_Smoothness", 0.8f);
        } else {
            metalMat.SetFloat("_Metallic", 0.95f);
            metalMat.SetFloat("_Glossiness", 0.8f);
        }

        // 1. 土台 (Base Plate - 少し丸みを持たせるための薄い円柱)
        GameObject basePlate = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        basePlate.name = "Stand_Base";
        basePlate.transform.SetParent(standRoot.transform, false);
        basePlate.transform.localScale = new Vector3(0.12f, 0.01f, 0.12f); // 直径12cm、高さ1cmの円盤
        basePlate.transform.localPosition = new Vector3(0f, 1.155f, 0.8f);
        basePlate.GetComponent<Renderer>().material = standMat;
        DestroyImmediate(basePlate.GetComponent<Collider>());

        // 2. 背もたれ支柱 (Back Support - 携帯を置くための傾いた板)
        GameObject backPlate = GameObject.CreatePrimitive(PrimitiveType.Cube);
        backPlate.name = "Stand_Back";
        backPlate.transform.SetParent(standRoot.transform, false);
        backPlate.transform.localScale = new Vector3(0.08f, 0.12f, 0.01f);
        backPlate.transform.localPosition = new Vector3(0f, 1.21f, 0.81f);
        backPlate.transform.localRotation = Quaternion.Euler(20f, 0f, 0f); // 20度傾ける
        backPlate.GetComponent<Renderer>().material = standMat;
        DestroyImmediate(backPlate.GetComponent<Collider>());

        // 3. 充電コネクタ突起 (Connector - シルバーの充電端子ピン)
        GameObject connector = GameObject.CreatePrimitive(PrimitiveType.Cube);
        connector.name = "Stand_Connector";
        connector.transform.SetParent(standRoot.transform, false);
        connector.transform.localScale = new Vector3(0.015f, 0.01f, 0.005f);
        connector.transform.localPosition = new Vector3(0f, 1.16f, 0.8f);
        connector.transform.localRotation = Quaternion.Euler(20f, 0f, 0f);
        connector.GetComponent<Renderer>().material = metalMat;
        DestroyImmediate(connector.GetComponent<Collider>());

        // 4. ネオンライン装飾
        GameObject lightBar = GameObject.CreatePrimitive(PrimitiveType.Cube);
        lightBar.name = "Stand_NeonLight";
        lightBar.transform.SetParent(standRoot.transform, false);
        lightBar.transform.localScale = new Vector3(0.05f, 0.002f, 0.002f);
        lightBar.transform.localPosition = new Vector3(0f, 1.161f, 0.805f);
        lightBar.transform.localRotation = Quaternion.Euler(20f, 0f, 0f);
        lightBar.GetComponent<Renderer>().material = neonMat;
        DestroyImmediate(lightBar.GetComponent<Collider>());

        // コライダー
        BoxCollider boxCol = standRoot.AddComponent<BoxCollider>();
        boxCol.size = new Vector3(0.15f, 0.15f, 0.15f);
        boxCol.center = new Vector3(0f, 1.2f, 0.8f);

        // UdonBehaviour をアタッチしてクリックで TogglePhone を呼ぶ
        UdonBehaviour btnUdon = standRoot.AddComponent<UdonBehaviour>();
        btnUdon.programSource = udonBehaviour.programSource;
        btnUdon.interactText = "スマホを取り出す/しまう";
        
        VRCGuestBook btnProxy = (VRCGuestBook)UdonSharpEditor.UdonSharpEditorUtility.GetProxyBehaviour(btnUdon);
        if (btnProxy != null)
        {
            Undo.RecordObject(btnProxy, "Set mainSystem of Stand");
            btnProxy.mainSystem = guestBook;
            UdonSharpEditor.UdonSharpEditorUtility.CopyProxyToUdon(btnProxy);
            EditorUtility.SetDirty(btnProxy);
            EditorUtility.SetDirty(btnUdon);
        }

        standRoot.layer = LayerMask.NameToLayer("Default");
    }

    private static void CreateCallButton(UdonBehaviour udonBehaviour, VRCGuestBook guestBook, GameObject packGo, GameObject tabletGo)
    {
        // 固定設置時の「呼び出しボタン」
        GameObject callBtnGo = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        Undo.RegisterCreatedObjectUndo(callBtnGo, "Create VRCGuestBook_CallButton");
        callBtnGo.name = "VRCGuestBook_CallButton";
        callBtnGo.transform.SetParent(packGo.transform, false);
        
        callBtnGo.transform.position = tabletGo.transform.position + tabletGo.transform.right * 0.25f + tabletGo.transform.up * 0.01f;
        callBtnGo.transform.rotation = tabletGo.transform.rotation;
        callBtnGo.transform.localScale = new Vector3(0.12f, 0.03f, 0.12f);

        Renderer rend = callBtnGo.GetComponent<Renderer>();
        if (rend != null)
        {
            Material btnMat = new Material(Shader.Find("Standard"));
            btnMat.color = new Color(1f, 0f, 0.2f);
            btnMat.EnableKeyword("_EMISSION");
            btnMat.SetColor("_EmissionColor", new Color(0.4f, 0f, 0.08f));
            rend.material = btnMat;
        }

        Collider col = callBtnGo.GetComponent<Collider>();
        if (col == null) col = callBtnGo.AddComponent<CapsuleCollider>();

        UdonBehaviour btnUdon = callBtnGo.AddComponent<UdonBehaviour>();
        btnUdon.programSource = udonBehaviour.programSource;
        btnUdon.interactText = "スマホを初期位置に戻す";
        
        VRCGuestBook btnProxy = (VRCGuestBook)UdonSharpEditor.UdonSharpEditorUtility.GetProxyBehaviour(btnUdon);
        if (btnProxy != null)
        {
            Undo.RecordObject(btnProxy, "Set mainSystem of Respawner");
            btnProxy.mainSystem = guestBook;
            UdonSharpEditor.UdonSharpEditorUtility.CopyProxyToUdon(btnProxy);
            EditorUtility.SetDirty(btnProxy);
            EditorUtility.SetDirty(btnUdon);
        }

        callBtnGo.layer = LayerMask.NameToLayer("Default");
    }

    private static void SetLayerRecursive(GameObject go, int layer)
    {
        go.layer = layer;
        foreach (Transform child in go.transform)
        {
            SetLayerRecursive(child.gameObject, layer);
        }
    }

    private static void RegisterUdonEvent(Button button, UdonBehaviour udonBehaviour, string eventName)
    {
        UnityEditor.Events.UnityEventTools.AddStringPersistentListener(
            button.onClick, 
            new UnityEngine.Events.UnityAction<string>(udonBehaviour.SendCustomEvent), 
            eventName
        );
    }

    private static Shader GetSafeShader()
    {
        Shader s = Shader.Find("Universal Render Pipeline/Lit");
        if (s == null) s = Shader.Find("Standard");
        if (s == null) s = Shader.Find("Legacy Shaders/Diffuse");
        if (s == null) s = Shader.Find("Diffuse");
        return s;
    }
}
#endif
