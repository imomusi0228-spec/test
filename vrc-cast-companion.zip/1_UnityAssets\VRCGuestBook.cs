using UdonSharp;
using UnityEngine;
using VRC.SDK3.StringLoading;
using VRC.SDKBase;
using VRC.Udon;
using VRC.Udon.Common.Interfaces;
using VRC.SDK3.Components;
using UnityEngine.UI;

[UdonBehaviourSyncMode(BehaviourSyncMode.Manual)]
public class VRCGuestBook : UdonSharpBehaviour
{
    [Header("Server Settings")]
    [Tooltip("APIのベースURL (例: http://localhost:8080/api)")]
    public VRCUrl baseUrl;
    [Tooltip("手帳ID (ダッシュボードで作成した手帳のUUID)")]
    public string bookId;

    [Header("Dynamic URL Loader (Helper)")]
    [Tooltip("動的URLを生成するためのダミーの VRCUrlInputField (非表示でも可)")]
    public VRCUrlInputField urlBufferInputField;

    // 内部の通常の InputField をキャッシュ
    private InputField _internalUrlInputField;

    [Header("Security Settings")]
    [Tooltip("キャスト専用ページを開くための暗証番号 (数字4桁など)")]
    public string passcode = "1234";

    [Header("UI References")]
    [Tooltip("名前の入力欄")]
    public InputField nameInputField;
    [Tooltip("一言コメントなどの入力欄")]
    public InputField commentInputField;
    [Tooltip("名簿の一覧を表示するテキスト (TextMeshPro または Text)")]
    public Text listDisplayText;
    [Tooltip("エラーやステータスを表示するメッセージテキスト")]
    public Text statusDisplayText;
    [Tooltip("パスコード入力用のフィールド")]
    public InputField passcodeInputField;

    [Header("Panel References")]
    [Tooltip("一般ゲスト用のコメント記入パネル")]
    public GameObject guestPanel;
    [Tooltip("パスコード入力（ロック画面）パネル")]
    public GameObject lockPanel;
    [Tooltip("キャスト専用の名簿閲覧パネル")]
    public GameObject castPanel;

    [Header("Respawn Button Settings (Optional)")]
    [Tooltip("メインの名簿システムオブジェクト（3Dスマホスタンドとして動作させる場合のみアタッチ）")]
    public VRCGuestBook mainSystem;

    [Header("Cast Selection UI (Optional)")]
    [Tooltip("出勤キャスト選択用ボタン群（最大5個）")]
    public GameObject[] castButtons;
    [Tooltip("出勤キャスト名表示用テキスト群（最大5個）")]
    public Text[] castNameTexts;

    [Header("Local Smartphone Settings")]
    [Tooltip("スマートフォン筐体オブジェクト")]
    public GameObject tabletObject;
    [Tooltip("スマートフォン画面のCanvasオブジェクト")]
    public GameObject canvasObject;

    private bool _isPhoneActive = false;

    // ワールド内の全員に同期する名簿のテキストデータ
    [UdonSynced]
    private string syncedGuestList = "";

    private void Start()
    {
        // ログインしているローカルプレイヤーの名前を初期値として入力欄に入れる
        if (nameInputField != null && Networking.LocalPlayer != null)
        {
            nameInputField.text = Networking.LocalPlayer.displayName;
        }

        // 初期UI表示状態のセットアップ (一般記名画面のみ表示)
        if (lockPanel != null) lockPanel.SetActive(false);
        if (castPanel != null) castPanel.SetActive(false);
        if (guestPanel != null) guestPanel.SetActive(true);

        if (statusDisplayText != null)
        {
            statusDisplayText.text = "システム起動完了";
        }

        // 初期状態では携帯スマホは非表示
        if (tabletObject != null) tabletObject.SetActive(false);
        if (canvasObject != null) canvasObject.SetActive(false);

        FetchGuestList();
        FetchCastList();
    }

    // プレイヤーがワールドに入室した際のイベント
    public override void OnPlayerJoined(VRCPlayerApi player)
    {
        if (player == null) return;

        if (player.isLocal)
        {
            SendJoinRequest(player.displayName);
        }
    }

    // 入室自動登録リクエストの送信
    private void SendJoinRequest(string playerName)
    {
        string urlStr = $"{baseUrl.Get()}/join?name={UrlEncode(playerName)}&book_id={bookId}";
        VRCUrl url = CreateDynamicUrl(urlStr);

        if (!Networking.IsOwner(gameObject))
        {
            Networking.SetOwner(Networking.LocalPlayer, gameObject);
        }

        VRCStringDownloader.LoadUrl(url, (IUdonEventReceiver)this);
    }

    // 「登録する / 送信する」ボタンから呼び出されるイベント
    public void OnRegisterClick()
    {
        if (nameInputField == null || string.IsNullOrEmpty(nameInputField.text))
        {
            ShowStatus("名前を入力してください。");
            return;
        }

        string guestName = nameInputField.text.Trim();
        string comment = commentInputField != null ? commentInputField.text.Trim() : "";
        string vrcId = Networking.LocalPlayer != null ? Networking.LocalPlayer.displayName : guestName;

        ShowStatus("送信中...");

        string urlStr = $"{baseUrl.Get()}/register?name={UrlEncode(guestName)}&comment={UrlEncode(comment)}&vrcid={UrlEncode(vrcId)}&book_id={bookId}";
        VRCUrl url = CreateDynamicUrl(urlStr);

        if (!Networking.IsOwner(gameObject))
        {
            Networking.SetOwner(Networking.LocalPlayer, gameObject);
        }

        VRCStringDownloader.LoadUrl(url, (IUdonEventReceiver)this);
    }

    // キャスト専用パネルのロック解除を試みる
    public void OnUnlockClick()
    {
        if (passcodeInputField == null) return;

        if (passcodeInputField.text == passcode)
        {
            if (lockPanel != null) lockPanel.SetActive(false);
            if (castPanel != null) castPanel.SetActive(true);
            if (guestPanel != null) guestPanel.SetActive(false);
            
            ShowStatus("ロック解除成功");
            FetchGuestList();
        }
        else
        {
            ShowStatus("パスコードが一致しません");
            passcodeInputField.text = "";
        }
    }

    // 再びロック状態に戻す (通常画面へ戻る)
    public void OnLockClick()
    {
        if (lockPanel != null) lockPanel.SetActive(false);
        if (castPanel != null) castPanel.SetActive(false);
        if (guestPanel != null) guestPanel.SetActive(true);
        if (passcodeInputField != null) passcodeInputField.text = "";
        
        ShowStatus("ロックされました");
    }

    // パスコード入力画面を開く
    public void OnOpenLockClick()
    {
        if (lockPanel != null) lockPanel.SetActive(true);
        if (castPanel != null) castPanel.SetActive(false);
        if (guestPanel != null) guestPanel.SetActive(false);
        if (passcodeInputField != null) passcodeInputField.text = "";
        
        ShowStatus("暗証番号を入力してください");
    }

    // サーバーから名簿データを取得する
    public void FetchGuestList()
    {
        string urlStr = $"{baseUrl.Get()}/udon/guests?book_id={bookId}";
        VRCUrl url = CreateDynamicUrl(urlStr);
        VRCStringDownloader.LoadUrl(url, (IUdonEventReceiver)this);
    }

    // サーバーから出勤キャスト一覧を取得する
    public void FetchCastList()
    {
        string urlStr = $"{baseUrl.Get()}/udon/casts?book_id={bookId}";
        VRCUrl url = CreateDynamicUrl(urlStr);
        VRCStringDownloader.LoadUrl(url, (IUdonEventReceiver)this);
    }

    // スマートフォンの取り出し/しまうトグル
    public void TogglePhone()
    {
        _isPhoneActive = !_isPhoneActive;

        if (tabletObject != null)
        {
            tabletObject.SetActive(_isPhoneActive);
        }
        if (canvasObject != null)
        {
            canvasObject.SetActive(_isPhoneActive);
        }

        if (_isPhoneActive)
        {
            ShowStatus("スマホを取り出しました");
            UpdatePhonePosition();
        }
        else
        {
            ShowStatus("スマホをしまいました");
        }
    }

    // 3Dスタンドオブジェクトからの物理的なインタラクトを受け取る
    public override void Interact()
    {
        if (mainSystem != null)
        {
            mainSystem.SendCustomEvent("TogglePhone");
        }
        else
        {
            TogglePhone();
        }
    }

    // プレイヤーの移動に追従させるため LateUpdate で同期
    private void LateUpdate()
    {
        if (!_isPhoneActive) return;
        UpdatePhonePosition();
    }

    private void UpdatePhonePosition()
    {
        VRCPlayerApi localPlayer = Networking.LocalPlayer;
        if (localPlayer == null) return;

        Vector3 targetPos = Vector3.zero;
        Quaternion targetRot = Quaternion.identity;

        if (localPlayer.IsUserInVR())
        {
            // VRプレイヤー: 右手（手のひら）に追従
            VRCPlayerApi.TrackingData handData = localPlayer.GetTrackingData(VRCPlayerApi.TrackingDataType.RightHand);
            // 手のひらから少し浮かせて見やすい角度に配置 (手の甲側にオフセット)
            targetPos = handData.position + handData.rotation * new Vector3(-0.02f, 0.05f, 0.05f);
            targetRot = handData.rotation * Quaternion.Euler(45f, 180f, 0f); // 画面をプレイヤーに向ける
        }
        else
        {
            // デスクトッププレイヤー: カメラの正面（視界の右下前方のHUD位置）に固定表示
            VRCPlayerApi.TrackingData headData = localPlayer.GetTrackingData(VRCPlayerApi.TrackingDataType.Head);
            // カメラの前方 0.35m、右に 0.12m、下に 0.08m オフセットし、画面を少し手前に傾ける
            targetPos = headData.position + headData.rotation * new Vector3(0.12f, -0.08f, 0.35f);
            targetRot = headData.rotation * Quaternion.Euler(10f, -15f, 0f);
        }

        if (tabletObject != null)
        {
            tabletObject.transform.position = targetPos;
            tabletObject.transform.rotation = targetRot;
        }
        if (canvasObject != null)
        {
            // スマホ筐体の表面（厚さ 8mm のため、ローカル座標で Z軸(forward) +0.0045m）にCanvasを吸着
            canvasObject.transform.position = targetPos + (tabletObject != null ? tabletObject.transform.forward * 0.0045f : Vector3.zero);
            canvasObject.transform.rotation = targetRot;
        }
    }

    // 出勤キャスト選択時のイベント
    public void OnCastClick0() { SelectCast(0); }
    public void OnCastClick1() { SelectCast(1); }
    public void OnCastClick2() { SelectCast(2); }
    public void OnCastClick3() { SelectCast(3); }
    public void OnCastClick4() { SelectCast(4); }

    private void SelectCast(int index)
    {
        if (castNameTexts != null && index < castNameTexts.Length && castNameTexts[index] != null && nameInputField != null)
        {
            nameInputField.text = castNameTexts[index].text;
            ShowStatus($"{castNameTexts[index].text} を選択しました");
        }
    }

    // 通信成功時のコールバック
    public override void OnStringLoadSuccess(IVRCStringDownload download)
    {
        string result = download.Result;
        string requestUrl = download.Url.Get();

        // ゲスト名簿取得のレスポンス処理
        if (requestUrl.Contains("/udon/guests"))
        {
            ShowStatus("同期完了");

            if (Networking.IsOwner(gameObject))
            {
                syncedGuestList = result;
                RequestSerialization();
                UpdateDisplay();
            }
        }
        // 出勤キャスト取得のレスポンス処理 (形式: CastA|CastB|CastC)
        else if (requestUrl.Contains("/udon/casts"))
        {
            if (string.IsNullOrEmpty(result) || result == "none")
            {
                for (int i = 0; i < castButtons.Length; i++)
                {
                    if (castButtons[i] != null) castButtons[i].SetActive(false);
                }
                return;
            }

            string[] names = result.Split('|');
            for (int i = 0; i < castButtons.Length; i++)
            {
                if (i < names.Length && !string.IsNullOrEmpty(names[i]))
                {
                    if (castButtons[i] != null) castButtons[i].SetActive(true);
                    if (castNameTexts[i] != null) castNameTexts[i].text = names[i];
                }
                else
                {
                    if (castButtons[i] != null) castButtons[i].SetActive(false);
                }
            }
        }
    }

    // 通信失敗時のコールバック
    public override void OnStringLoadError(IVRCStringDownload download)
    {
        Debug.LogError($"[VRCGuestBook] 通信エラー: {download.Error}");
        ShowStatus($"通信エラー: {download.ErrorCode}");
    }

    // 同期データを受信した時のコールバック
    public override void OnDeserialization()
    {
        UpdateDisplay();
    }

    // 名簿テキストを画面UIに整形して表示する
    private void UpdateDisplay()
    {
        if (listDisplayText == null) return;

        string[] lines = syncedGuestList.Split(';');
        string formattedText = "";
        int displayLimit = 20;
        int count = 0;

        foreach (string line in lines)
        {
            if (string.IsNullOrEmpty(line)) continue;
            if (count >= displayLimit) break;

            string[] parts = line.Split('|');
            if (parts.Length >= 3)
            {
                string name = parts[0];
                string dateTime = parts[1];
                string comment = parts[2];
                string visits = parts.Length > 3 ? parts[3] : "1";

                formattedText += $"【{dateTime}】 {name} (来店: {visits}回)\n";
                if (!string.IsNullOrEmpty(comment) && comment != "なし")
                {
                    formattedText += $"  ↳ \"{comment}\"\n";
                }
                formattedText += "───────────────────────────────\n";
                count++;
            }
        }

        if (string.IsNullOrEmpty(formattedText))
        {
            formattedText = "登録されているゲストはいません。\n最初の記名をお願いします！";
        }

        listDisplayText.text = formattedText;
    }

    private void ShowStatus(string msg)
    {
        if (statusDisplayText != null)
        {
            statusDisplayText.text = msg;
        }
    }

    private string UrlEncode(string str)
    {
        if (string.IsNullOrEmpty(str)) return "";
        
        return str
            .Replace("%", "%25")
            .Replace(" ", "%20")
            .Replace("&", "%26")
            .Replace("=", "%3D")
            .Replace("?", "%3F")
            .Replace("/", "%2F")
            .Replace(":", "%3A")
            .Replace(",", "%2C")
            .Replace("\n", "%0A");
    }

    private VRCUrl CreateDynamicUrl(string urlStr)
    {
        if (urlBufferInputField == null)
        {
            Debug.LogError("[VRCGuestBook] urlBufferInputField がインスペクターで設定されていません！");
            return null;
        }

        if (_internalUrlInputField == null)
        {
            _internalUrlInputField = urlBufferInputField.GetComponent<InputField>();
        }

        if (_internalUrlInputField != null)
        {
            _internalUrlInputField.text = urlStr;
            return urlBufferInputField.GetUrl();
        }

        return urlBufferInputField.GetUrl();
    }
}
